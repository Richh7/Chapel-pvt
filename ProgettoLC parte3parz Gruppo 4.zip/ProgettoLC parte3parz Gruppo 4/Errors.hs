{-# OPTIONS_GHC -Wno-incomplete-patterns #-}
module Errors where

    import AbsChapel
    
    data ErrorTypeChecking a
        = ProtNoFunDefError String (Maybe a)
        | ProtNameError String (Maybe a) (Maybe a)
        | ParamFunDefProtError String (Maybe a) (Maybe a)
        | InconsistencyNumParamFunError String (Maybe a) (Maybe a) Int Int
        | TypeMismatchFunError String (Maybe a) (Maybe a) String String
        | AlreadyDefinedFunError String (Maybe a)
        | UndeclaredFunDefinitionError String (Maybe a)
        | WrongNameFunCallError String (Maybe a) (Maybe a) String 
        | FunCallNumArgError String (Maybe a) (Maybe a) Int Int
        | UndefinedFunCallError String (Maybe a) (Maybe a)
        | UndeclaredFunCallError String (Maybe a)
        | VoidReturnInFunctionError String (Maybe a) String
        | ReturnMismatchInFunctionError String (Maybe a) String String
        | ReturnInNonFunBlockError (Maybe a)
        | NonBoolWardError (Maybe a) String
        | TypeAssError (Maybe a) String String
        | ConstAssError (Maybe a) LExpr
        | AssgnMatError (Maybe a) String String
        | PowAssgnNonIntExpError (Maybe a) String
        | AssgnBoolError (Maybe a) String String
        | NonArithIncDecError (Maybe a) String
        | MissingRetError String (Maybe a) String
        | ArrayElemTypeInconsistencyError (Maybe a) Int String String
        | ArrayAccessDimError String (Maybe a) Int Int
        --DeclsErrors
        | VarDeclTypeError (Maybe a) String String
        | MultipleNameVarError String (Maybe a) (Maybe a)
        --RexprErrors
        | OrExprError (Maybe a) String String String
        | AndExprError (Maybe a) String String String
        | NotExprError (Maybe a) String
        | NonNumericComparisonError (Maybe a) String String
        | SumExprError (Maybe a) String String String
        | SubExprError (Maybe a) String String String
        | MulExprError (Maybe a) String String String
        | DivExprError (Maybe a) String String String
        | ModExprError (Maybe a) String String String
        | PowNonIntExpError (Maybe a) String
        | PowExprError (Maybe a) String String String
        | NegExprError (Maybe a) String
        | DerefError (Maybe a) String
        | ArrayAccessToVarError String (Maybe a) String
        | ArrAccessToConstError String (Maybe a) (Maybe a)
        | ArrAccessToFunError String (Maybe a) (Maybe a)
        | DerArrPtrDimError (Maybe a) Int Int
        | DerArrPtrAccessToVarError (Maybe a) String
        | UnexpectedFunIdError String (Maybe a) (Maybe a)
        | NonIntArrayAccessIndexErr Int String (Maybe a)
        | RefParamConstError String String (Maybe a) (Maybe a)
        | RefParamRExprError String (Maybe a) (Maybe a)
        --RExprErrors -> FunCall
        | InModTypeError String (Maybe a) (Maybe a) String String 
        | RefModTypeError String (Maybe a) (Maybe a) String String
        --RExprErrors -> ComplexRExpr        --RExprErrors -> Lexp
        | UndeclaredVarError (Maybe a) String
        | ParamFunSameNameError String String (Maybe a) (Maybe a)
        | NotBasTypeRefParamError String (Maybe a) String String


    prtErrs x = case x of
        ProtNoFunDefError id pos -> "Errore in posizione (" ++ 
                                     show (fst (getRowCol pos)) ++ ", " ++
                                     show (snd (getRowCol pos)) ++ 
                                    "): il prototipo " ++ id ++ " non ha la relativa definizione."
        ProtNameError name currPos oldPos -> "Errore in posizione (" ++ 
                                                show (fst (getRowCol currPos)) ++ ", " ++
                                                show (snd (getRowCol currPos)) ++ 
                                                "): nome di prototipo " ++
                                                name ++ " già utilizzato in posizione (" ++ 
                                                show (fst (getRowCol oldPos)) ++ ", " ++
                                                show (snd (getRowCol oldPos)) ++ ")."
        ParamFunDefProtError name posDef posProt -> "Errore in posizione (" ++ 
                                                     show (fst (getRowCol posDef)) ++ ", " ++
                                                     show (snd (getRowCol posDef)) ++ 
                                                     "): i parametri della definizione di " ++
                                                     name ++ " non combaciano con quelli del prototipo in posizione (" ++ 
                                                     show (fst (getRowCol posProt)) ++ ", " ++
                                                     show (snd (getRowCol posProt)) ++ ")."
        InconsistencyNumParamFunError name posDef posProt n1 n2 -> "Errore in posizione (" ++ 
                                    show (fst (getRowCol posDef)) ++ ", " ++
                                    show (snd (getRowCol posDef)) ++
                                    "): " ++ show n1 ++ " parametri della dichiarazione di " ++
                                    name ++ ", attesi " ++ show n2 ++ " parametri dal prototipo in posizione (" ++ 
                                    show (fst (getRowCol posProt)) ++ ", " ++
                                    show (snd (getRowCol posProt)) ++ ")."
        TypeMismatchFunError name posDef posProt tipoDef tipoProt -> "Errore in posizione (" ++ 
                                    show (fst (getRowCol posDef)) ++ ", " ++
                                    show (snd (getRowCol posDef)) ++
                                    "): tipo di ritorno " ++ 
                                    tipoDef ++ " nella dichiarazione di " ++
                                    name ++ ", atteso " ++ tipoProt ++ " dal prototipo in posizione (" ++ 
                                    show (fst (getRowCol posProt)) ++ ", " ++
                                    show (snd (getRowCol posProt)) ++ ")."
        AlreadyDefinedFunError name posDef -> "Errore in posizione (" ++ 
                                    show (fst (getRowCol posDef)) ++ ", " ++
                                    show (snd (getRowCol posDef)) ++
                                    "): " ++ "la funzione " ++ name ++ " è già stata definita."
        UndeclaredFunDefinitionError name posDef -> "Errore in posizione (" ++ 
                                    show (fst (getRowCol posDef)) ++ ", " ++
                                    show (snd (getRowCol posDef)) ++
                                    "): " ++ "dichiarazione di funzione " ++ name ++ " in assenza di relativo prototipo."
        WrongNameFunCallError name pos posPrec classe -> "Errore in posizione (" ++ 
                                    show (fst (getRowCol pos)) ++ ", " ++
                                    show (snd (getRowCol pos)) ++
                                    "): " ++ "chiamata alla funzione " ++ name ++ ", ma " ++ name ++ 
                                    " è una " ++ classe ++ ", definita in posizione " ++
                                    "(" ++ show (fst (getRowCol posPrec)) ++ ", " ++
                                    show (snd (getRowCol posPrec)) ++ ")."
        FunCallNumArgError name posCall posDef n1 n2 -> "Errore in posizione (" ++ 
                                    show (fst (getRowCol posCall)) ++ ", " ++
                                    show (snd (getRowCol posCall)) ++
                                    "): " ++ show n1 ++ " parametri della chiamata di " ++
                                    name ++ ", attesi " ++ show n2 ++ " parametri dal prototipo in posizione (" ++ 
                                    show (fst (getRowCol posDef)) ++ ", " ++
                                    show (snd (getRowCol posDef)) ++ ")."
        UndefinedFunCallError name posCall posDef -> "Errore in posizione (" ++ 
                                    show (fst (getRowCol posCall)) ++ ", " ++
                                    show (snd (getRowCol posCall)) ++
                                    "): " ++ "chiamata di funzione " ++ name ++ ", dichiarata in posizione (" ++
                                    show (fst (getRowCol posDef)) ++ ", " ++
                                    show (snd (getRowCol posDef)) ++ ") ma non definita."
        UndeclaredFunCallError name posCall -> "Errore in posizione (" ++ 
                                    show (fst (getRowCol posCall)) ++ ", " ++
                                    show (snd (getRowCol posCall)) ++
                                    "): " ++ "chiamata di funzione " ++ name ++ ", mai dichiarata."
        VoidReturnInFunctionError name pos tipoExp -> "Errore in posizione (" ++ 
                                    show (fst (getRowCol pos)) ++ ", " ++
                                    show (snd (getRowCol pos)) ++
                                    "): " ++ "la funzione " ++ name ++ " si aspetta un return di tipo " ++ tipoExp ++
                                    ", ma è presente un return da procedura."
        ReturnMismatchInFunctionError name pos tipoExp tipoRet -> "Errore in posizione (" ++ 
                                    show (fst (getRowCol pos)) ++ ", " ++
                                    show (snd (getRowCol pos)) ++
                                    "): " ++ "la funzione " ++ name ++ " si aspetta un return di tipo " ++ tipoExp ++
                                    ", ma viene restituito un tipo " ++ tipoRet ++ "."
        ReturnInNonFunBlockError pos -> "Errore in posizione (" ++ 
                                    show (fst (getRowCol pos)) ++ ", " ++
                                    show (snd (getRowCol pos)) ++
                                    "): " ++ "return in un blocco che non è una dichiarazione di funzione."
        NonBoolWardError pos tipoGuardia -> "Errore in posizione (" ++ 
                                    show (fst (getRowCol pos)) ++ ", " ++
                                    show (snd (getRowCol pos)) ++
                                    "): " ++ "la guardia deve essere booleana, ma è di tipo " ++ tipoGuardia ++ "."
        TypeAssError pos tipoLStr tipoRStr -> "Errore in posizione (" ++ 
                                    show (fst (getRowCol pos)) ++ ", " ++
                                    show (snd (getRowCol pos)) ++
                                    "): " ++ "il tipo di sinistra nell'assegnamento " ++ tipoLStr ++ 
                                    " non è un sovratipo del tipo di destra " ++ tipoRStr ++ "."
        ConstAssError pos lNew -> case lNew of
            (IdNew _ id _) -> "Errore in posizione (" ++ 
                              show (fst (getRowCol pos)) ++ ", " ++
                              show (snd (getRowCol pos)) ++
                              "): " ++ "ridefinizione della costante " ++ idToStr1 id ++ "."
        AssgnMatError pos lTypeStr rTypeStr -> "Errore in posizione (" ++ 
                                    show (fst (getRowCol pos)) ++ ", " ++
                                    show (snd (getRowCol pos)) ++
                                    "): " ++ "tipo di sinistra = " ++ lTypeStr ++ 
                                    ", tipo di destra = " ++ rTypeStr ++ ". Il sovratipo non è numerico."
        PowAssgnNonIntExpError pos tipoRStr -> "Errore in posizione (" ++ 
                                    show (fst (getRowCol pos)) ++ ", " ++
                                    show (snd (getRowCol pos)) ++
                                    "): " ++ "il tipo dell'esponente " ++ tipoRStr ++ 
                                    " non è un sottotipo di int."
        AssgnBoolError pos tipoLStr tipoRStr -> "Errore in posizione (" ++ 
                                    show (fst (getRowCol pos)) ++ ", " ++
                                    show (snd (getRowCol pos)) ++
                                    "): " ++ "tipo di sinistra = " ++ tipoLStr ++ 
                                    ", tipo di destra = " ++ tipoRStr ++ ". Entrambi devono essere bool."
        NonArithIncDecError pos tipoLNew -> "Errore in posizione (" ++ 
                                    show (fst (getRowCol pos)) ++ ", " ++
                                    show (snd (getRowCol pos)) ++
                                    "): " ++ "Incremento/Decremento su variabile di tipo " ++ 
                                    tipoLNew ++ ", sono ammessi solo int o real."
        MissingRetError funName pos tipo -> "Errore in posizione (" ++ 
                                    show (fst (getRowCol pos)) ++ ", " ++
                                    show (snd (getRowCol pos)) ++
                                    "): " ++ "la funzione " ++ funName ++ " qui dichiarata si aspetta un return di tipo " ++
                                    tipo ++ " che non è presente nel corpo." 
        ArrayElemTypeInconsistencyError pos n tipoStr cRExprTipoStr -> "Errore in posizione (" ++ 
                                    show (fst (getRowCol pos)) ++ ", " ++
                                    show (snd (getRowCol pos)) ++
                                    "): " ++ "inconsistenza di tipo nella dichiarazione di array, primo elemento è di tipo " ++
                                    tipoStr ++ " mentre quello in posizione " ++ show n ++ " è di tipo " ++ cRExprTipoStr ++ "."  
        --DeclsErrors
        VarDeclTypeError pos typeStr cRExprNewStr -> "Errore in posizione (" ++ 
                                                     show (fst (getRowCol pos)) ++ ", " ++
                                                     show (snd (getRowCol pos)) ++
                                                     "): il tipo dichiarato " ++ typeStr ++
                                                     " non è compatibile col tipo della r-espressione, che è " ++
                                                     cRExprNewStr ++ "."
        MultipleNameVarError name currPos oldPos -> "Errore in posizione (" ++ 
                                                    show (fst (getRowCol currPos)) ++ ", " ++
                                                    show (snd (getRowCol currPos)) ++
                                                    "): nome " ++ name ++ " già utilizzato in posizione (" ++ 
                                                    show (fst (getRowCol oldPos)) ++ ", " ++
                                                    show (snd (getRowCol oldPos)) ++ ")."
        --RExprErrors
        OrExprError pos lTypeStr rTypeStr supStr -> "Errore in posizione (" ++
                                                    show (fst (getRowCol pos)) ++ ", " ++
                                                    show (snd (getRowCol pos)) ++ "). " ++
                                                    "E' stato eseguito un OR tra due espressioni di tipo: " ++
                                                    lTypeStr ++ " e " ++ rTypeStr ++ 
                                                    ". Il loro tipo inferito è: " ++ supStr ++ ", che non è bool."
        AndExprError pos lTypeStr rTypeStr supStr -> "Errore in posizione (" ++
                                                     show (fst (getRowCol pos)) ++ ", " ++
                                                     show (snd (getRowCol pos)) ++ "). " ++
                                                     "E' stato eseguito un AND tra due espressioni di tipo: " ++
                                                     lTypeStr ++ " e " ++ rTypeStr ++ 
                                                     ". Il loro tipo inferito è: " ++ supStr ++ ", che non è bool."
        NotExprError pos rTypeStr -> "Errore in posizione (" ++
                                     show (fst (getRowCol pos)) ++ ", " ++
                                     show (snd (getRowCol pos)) ++ "). " ++
                                     "E' stato eseguito un NOT in un'espressione di tipo: " ++
                                     rTypeStr ++ ", che non è bool."
        NonNumericComparisonError pos lTypeStr rTypeStr -> "Errore in posizione (" ++
                                             show (fst (getRowCol pos)) ++ ", " ++
                                             show (snd (getRowCol pos)) ++ "). " ++
                                             "E' stato eseguito confronto tra due espressioni di tipo: " ++
                                             lTypeStr ++ " e " ++ rTypeStr ++ "che non sono numerici."
        SumExprError pos lTypeStr rTypeStr supStr -> "Errore in posizione (" ++
                                                     show (fst (getRowCol pos)) ++ ", " ++
                                                     show (snd (getRowCol pos)) ++ "). " ++
                                                     "E' stata eseguita una SOMMA tra due espressioni di tipo: " ++
                                                     lTypeStr ++ " e " ++ rTypeStr ++ 
                                                     ". Il loro tipo inferito è: " ++ supStr ++ ", che non è un tipo aritmetico."
        SubExprError pos lTypeStr rTypeStr supStr -> "Errore in posizione (" ++
                                                     show (fst (getRowCol pos)) ++ ", " ++
                                                     show (snd (getRowCol pos)) ++ "). " ++
                                                     "E' stata eseguita una SOTTRAZIONE tra due espressioni di tipo: " ++
                                                     lTypeStr ++ " e " ++ rTypeStr ++ 
                                                     ". Il loro tipo inferito è: " ++ supStr ++ ", che non è un tipo aritmetico."
        MulExprError pos lTypeStr rTypeStr supStr -> "Errore in posizione (" ++
                                                     show (fst (getRowCol pos)) ++ ", " ++
                                                     show (snd (getRowCol pos)) ++ "). " ++
                                                     "E' stata eseguita una MOLTIPLICAZIONE tra due espressioni di tipo: " ++
                                                     lTypeStr ++ " e " ++ rTypeStr ++ 
                                                     ". Il loro tipo inferito è: " ++ supStr ++ ", che non è un tipo aritmetico."
        DivExprError pos lTypeStr rTypeStr supStr -> "Errore in posizione (" ++
                                                     show (fst (getRowCol pos)) ++ ", " ++
                                                     show (snd (getRowCol pos)) ++ "). " ++
                                                     "E' stata eseguita una DIVISIONE tra due espressioni di tipo: " ++
                                                     lTypeStr ++ " e " ++ rTypeStr ++ 
                                                     ". Il loro tipo inferito è: " ++ supStr ++ ", che non è un tipo aritmetico."
        ModExprError pos lTypeStr rTypeStr supStr -> "Errore in posizione (" ++
                                                     show (fst (getRowCol pos)) ++ ", " ++
                                                     show (snd (getRowCol pos)) ++ "). " ++
                                                     "E' stata eseguita un MODULO tra due espressioni di tipo: " ++
                                                     lTypeStr ++ " e " ++ rTypeStr ++ 
                                                     ". Il loro tipo inferito è: " ++ supStr ++ ", che non è un tipo aritmetico."
        PowNonIntExpError pos rNewTypeStr -> "Errore in posizione (" ++
                                             show (fst (getRowCol pos)) ++ ", " ++
                                             show (snd (getRowCol pos)) ++ "). " ++
                                             "E' stata eseguita una POTENZA con esponente di tipo: " ++
                                             rNewTypeStr ++ ", che non è un tipo intero."
        PowExprError pos lTypeStr rTypeStr supStr -> "Errore in posizione (" ++
                                                     show (fst (getRowCol pos)) ++ ", " ++
                                                     show (snd (getRowCol pos)) ++ "). " ++
                                                     "E' stata eseguita una POTENZA tra due espressioni di tipo: " ++
                                                     lTypeStr ++ " e " ++ rTypeStr ++ 
                                                     ". Il loro tipo inferito è: " ++ supStr ++ ", che non è un tipo aritmetico."
        NegExprError pos rTypeStr -> "Errore in posizione (" ++
                                     show (fst (getRowCol pos)) ++ ", " ++
                                     show (snd (getRowCol pos)) ++ "). " ++
                                     "E' stata eseguita una NEGAZIONE UNARIA di un' espressione di tipo: " ++
                                     rTypeStr ++ "che non è un tipo matematico." 
        InModTypeError name posFDecl actPos formTypeStr actTypeStr -> "Errore in posizione (" ++
                                        show (fst (getRowCol actPos)) ++ ", " ++
                                        show (snd (getRowCol actPos)) ++ "). " ++
                                        "Nella chiamata della funzione " ++ name ++ 
                                        " dichiarata in posizione (" ++ 
                                        show (fst (getRowCol posFDecl)) ++ ", " ++
                                        show (snd (getRowCol posFDecl)) ++ ") " ++
                                        " il parametro attuale è di tipo " ++ actTypeStr ++
                                        ", che non è un sottotipo del parametro formale di tipo " ++ formTypeStr ++ "." 
        RefModTypeError name posFDecl actPos formTypeStr actTypeStr -> "Errore in posizione (" ++
                                        show (fst (getRowCol actPos)) ++ ", " ++
                                        show (snd (getRowCol actPos)) ++ "). " ++
                                        "Nella chiamata della funzione " ++ name ++ 
                                        " dichiarata in posizione (" ++ 
                                        show (fst (getRowCol posFDecl)) ++ ", " ++
                                        show (snd (getRowCol posFDecl)) ++ ") " ++
                                        " il tipo " ++ actTypeStr ++ " del parametro attuale passato per riferimento è diverso dal tipo " ++ 
                                        formTypeStr ++ " del parametro formale." 
        DerefError pos bLTypeStr -> "Errore in posizione (" ++ 
                                    show (fst (getRowCol pos)) ++ ", " ++
                                    show (snd (getRowCol pos)) ++ "). " ++
                                    "Si è tentato di dereferenziare una variabile di tipo " ++ bLTypeStr ++ 
                                    " che non è un puntatore."
        UndeclaredVarError pos idStr -> "Errore in posizione (" ++ 
                                        show (fst (getRowCol pos)) ++ ", " ++
                                        show (snd (getRowCol pos)) ++ "). " ++
                                        "La variabile " ++ idStr ++ " non è stata dichiarata precedentemente."
        ArrayAccessDimError name pos dimArr dimAcc -> "Errore in posizione (" ++ 
                                        show (fst (getRowCol pos)) ++ ", " ++
                                        show (snd (getRowCol pos)) ++ "). " ++
                                        "L'array " ++ name ++ " ha " ++ show dimArr ++ " dimensioni, " ++
                                        "si sta tentando di accedervi come se fosse un array " ++ show dimAcc ++
                                        "-dimensionale."
        ArrayAccessToVarError name pos varTipo -> "Errore in posizione (" ++ 
                                        show (fst (getRowCol pos)) ++ ", " ++
                                        show (snd (getRowCol pos)) ++ "). " ++
                                        "Tentato accesso di tipo array a " ++ name ++ " che è una variabile di tipo " ++ varTipo ++ "."
        ArrAccessToConstError name pos posPrec -> "Errore in posizione (" ++ 
                                        show (fst (getRowCol pos)) ++ ", " ++
                                        show (snd (getRowCol pos)) ++ "). " ++
                                        "Tentato accesso di tipo array a " ++ name ++ " che è una costante dichiarata in posizione (" ++
                                        show (fst (getRowCol posPrec)) ++ ", " ++
                                        show (snd (getRowCol posPrec)) ++ "). "
        ArrAccessToFunError name pos posPrec -> "Errore in posizione (" ++ 
                                        show (fst (getRowCol pos)) ++ ", " ++
                                        show (snd (getRowCol pos)) ++ "). " ++
                                        "Tentato accesso di tipo array a " ++ name ++ " che è una funzione dichiarata in posizione (" ++
                                        show (fst (getRowCol posPrec)) ++ ", " ++
                                        show (snd (getRowCol posPrec)) ++ "). "
        DerArrPtrDimError pos dimArr dimAcc -> "Errore in posizione (" ++ 
                                        show (fst (getRowCol pos)) ++ ", " ++
                                        show (snd (getRowCol pos)) ++ "). " ++
                                        "Tentativo di accesso a un array " ++ show dimArr ++ "-dimensionale, " ++
                                        "si sta tentando di accedervi come se fosse un array " ++ show dimAcc ++
                                        "-dimensionale."
        DerArrPtrAccessToVarError pos varTipo -> "Errore in posizione (" ++ 
                                        show (fst (getRowCol pos)) ++ ", " ++
                                        show (snd (getRowCol pos)) ++ "). " ++
                                        "Tentato accesso di tipo array su espressione di tipo " ++ varTipo ++ "."
        UnexpectedFunIdError name pos posPrec -> "Errore in posizione (" ++ 
                                        show (fst (getRowCol pos)) ++ ", " ++
                                        show (snd (getRowCol pos)) ++ "). " ++
                                        "Atteso nome di variabile o costante ma " ++ name ++ 
                                        " è una funzione dichiarata in posizione (" ++
                                        show (fst (getRowCol posPrec)) ++ ", " ++
                                        show (snd (getRowCol posPrec)) ++ "). "
        NonIntArrayAccessIndexErr n tipo pos -> "Errore in posizione (" ++ 
                                        show (fst (getRowCol pos)) ++ ", " ++
                                        show (snd (getRowCol pos)) ++ "). " ++
                                        "L'indice numero " ++ show n ++ 
                                        " di accesso all'array è di tipo " ++
                                        tipo ++ ", dovrebbe essere int."
        RefParamConstError name nameL posFDecl posL  -> "Errore in posizione (" ++ 
                                        show (fst (getRowCol posL)) ++ ", " ++
                                        show (snd (getRowCol posL)) ++ "). " ++
                                        "Nella chiamata della funzione " ++ name ++ 
                                        " dichiarata in posizione (" ++ 
                                        show (fst (getRowCol posFDecl)) ++ ", " ++
                                        show (snd (getRowCol posFDecl)) ++ ") " ++
                                        " avviene il passaggio per riferimento della costante " ++ nameL ++ "." 
        RefParamRExprError name posFDecl posR -> "Errore in posizione (" ++ 
                                        show (fst (getRowCol posR)) ++ ", " ++
                                        show (snd (getRowCol posR)) ++ "). " ++
                                        "Nella chiamata della funzione " ++ name ++ 
                                        " dichiarata in posizione (" ++ 
                                        show (fst (getRowCol posFDecl)) ++ ", " ++
                                        show (snd (getRowCol posFDecl)) ++ ") " ++
                                        " avviene il passaggio per riferimento di una r-espressione. Sono ammesse solo l-espressioni."
        ParamFunSameNameError name paramName currPos oldPos -> "Errore in posizione (" ++ 
                                        show (fst (getRowCol currPos)) ++ ", " ++
                                        show (snd (getRowCol currPos)) ++
                                        "): Nella dichiarazione/definizione della funzione " ++ 
                                        name ++ ", il nome del parametro " ++ paramName ++ " è già stato utilizzato in posizione (" ++ 
                                        show (fst (getRowCol oldPos)) ++ ", " ++
                                        show (snd (getRowCol oldPos)) ++ "). Prototipo invalidato."
        NotBasTypeRefParamError name pos prmName prmType -> "Errore in posizione (" ++ 
                                        show (fst (getRowCol pos)) ++ ", " ++
                                        show (snd (getRowCol pos)) ++
                                        "): Nella dichiarazione della funzione " ++ 
                                        name ++ ", il parametro " ++ prmName ++ " è di tipo " ++ prmType ++
                                        ", ma gli unici tipi ammessi nel passaggio per riferimento sono quelli base. " ++
                                        "Prototipo invalidato."



    getRowCol (Just x) = x
    getRowCol _ = (0, 0)

    idToStr1 (Ident idStr) = idStr 