{-# OPTIONS_GHC -Wno-unrecognised-pragmas #-}
{-# HLINT ignore "Use isNothing" #-}
{-# HLINT ignore "Redundant bracket" #-}
{-# HLINT ignore "Use camelCase" #-}
{-# OPTIONS_GHC -Wno-incomplete-patterns #-}
module TypeChecker where

    import AbsChapel
    import Errors
    import qualified Data.Map as Map


    --Negli ambienti dobbiamo salvarci i numeri di riga

    --Per ogni dichiarazione o statement, salviamo la pila degli ambienti incontrati. 
    --Nel type-checking ad ogni livello facciamo pre-processing delle dichiarazioni di funzione.
    
    nonFunBlock_info = BlockInfo {
         name = "",
         defPos = Nothing, 
         declPos = Nothing, 
         tipoStr = "", 
         isFunDecl = False,
         hasReturn = True
      }

    --funzione chiamata dal main TestChapel
    typeChecking tree@(Strt pos protList fDefList declsList stmtsList) = (StrtNew pos fDefNewNode declsNewList stmtNewNode, (retErrList ++ stmtErr)) where
      empty_env = Env {env_fun = Map.empty, env_var = Map.empty, env_const = Map.empty, block_info = nonFunBlock_info}
      base_env = Env {  
         env_fun = Map.fromList [
            ("writeInt", ("void", Just (0, 0), True, ["intVal"], Map.fromList [("intVal", ParamInfo {modal = "in", tipo = "int", pos = Just (0, 0)})] )),
            ("writeReal", ("void", Just (0, 0), True, ["realVal"], Map.fromList [("realVal", ParamInfo {modal = "in", tipo = "real", pos = Just (0, 0)})] )),
            ("writeChar", ("void", Just (0, 0), True, ["charVal"], Map.fromList [("charVal", ParamInfo {modal = "in", tipo = "char", pos = Just (0, 0)})] )),
            ("writeString", ("void", Just (0, 0), True, ["stringVal"], Map.fromList [("stringVal", ParamInfo {modal = "in", tipo = "string", pos = Just (0, 0)})] )),
            ("readInt", ("int", Just (0, 0), True, [], Map.empty )),
            ("readReal", ("real", Just (0, 0), True, [], Map.empty )),
            ("readChar", ("char", Just (0, 0), True, [], Map.empty )),
            ("readString", ("string", Just (0, 0), True, [], Map.empty ))],
         env_var = Map.empty,
         env_const = Map.empty,
         block_info = nonFunBlock_info
      }
      (protEnv, protErr) = checkProt protList [empty_env, base_env] []
      (fDefNewNode, fDefEnv, fDefErr) = checkFDefList fDefList protEnv [] protErr
      (unDefProtErrs) = verificaProtDefiniz protList fDefEnv
      (declsNewList, declsEnv, declsErr) = checkDecls declsList fDefEnv (unDefProtErrs ++ fDefErr)--ogni elemento della lista di decls ha il suo stack
      (stmtNewNode, stmtEnv, stmtErr) = checkStmts stmtsList declsEnv [] declsErr
      retErrList = checkMissingReturnErr stmtEnv


    verificaProtDefiniz protList fDefEnv@(local:global) = case protList of
      [] -> []
      x:xs -> case x of
         FunProt pos id _ _ -> case Map.lookup (idToStr id) (env_fun local) of
             Nothing -> verificaProtDefiniz xs fDefEnv
             Just (_, _, isDefined, _, _) -> if isDefined
                  then 
                     verificaProtDefiniz xs fDefEnv
                  else
                     (ProtNoFunDefError (idToStr id) pos):verificaProtDefiniz xs fDefEnv
         ProcProt pos id _ -> case Map.lookup (idToStr id) (env_fun local) of
             Nothing -> verificaProtDefiniz xs fDefEnv
             Just (_, _, isDefined, _, _) -> if isDefined
                  then 
                     verificaProtDefiniz xs fDefEnv
                  else
                     (ProtNoFunDefError (idToStr id) pos):verificaProtDefiniz xs fDefEnv


   --CheckProt----------------------------------------------------------------------------------------------------------
    checkProt [] stack errs = (stack, errs)
    checkProt (x:xs) st@(local:global) errs = case x of
       FunProt pos name prmLst tipo -> if isNameInLoc nameStr local 
             then
                checkProt xs st (ProtNameError nameStr pos posPrec:errs) --se c'è tempo aggiungere info del nome già presente
             else if null newErrs && null refTypeErrs
                then 
                   checkProt xs ((insertProtEnv nameStr (tipoStr, pos, False, prmListToStrLst prmLst, prmMap) local):global) errs
                else 
                   checkProt xs st ((reverse refTypeErrs) ++ newErrs ++ errs)
         where
            nameStr = idToStr name
            tipoStr = funTypeToStr tipo
            posPrec = getPosPrec nameStr local
            (prmMap, newErrs) = paramListToMap (idToStr name) prmLst Map.empty []
            refTypeErrs = checkRefParamsType nameStr prmLst prmMap
       ProcProt pos name prmLst -> if isNameInLoc nameStr local
             then
                checkProt xs st (ProtNameError nameStr pos posPrec:errs) --se c'è tempo aggiungere info del nome già presente
             else if null newErrs && null refTypeErrs
                then 
                   checkProt xs ((insertProtEnv nameStr ("void", pos, False, prmListToStrLst prmLst, prmMap) local):global) errs
                else
                   checkProt xs st ((reverse refTypeErrs) ++ newErrs ++ errs)
         where
            nameStr = idToStr name
            posPrec = getPosPrec nameStr local
            (prmMap, newErrs) = paramListToMap (idToStr name) prmLst Map.empty []
            refTypeErrs = checkRefParamsType nameStr prmLst prmMap


    checkRefParamsType funIdStr prmLst prmMap = case prmLst of
       [] -> []
       (Param pos prmId _ _:xs) -> case Map.lookup (idToStr prmId) prmMap of
          Just prmInfo -> if modal prmInfo == "ref"
             then case tipo prmInfo of
                "int" -> checkRefParamsType funIdStr xs prmMap
                "real" -> checkRefParamsType funIdStr xs prmMap
                "bool" -> checkRefParamsType funIdStr xs prmMap
                "char" -> checkRefParamsType funIdStr xs prmMap
                _ -> (NotBasTypeRefParamError funIdStr pos (idToStr prmId) (tipo prmInfo)):checkRefParamsType funIdStr xs prmMap
             else
                checkRefParamsType funIdStr xs prmMap
          _ -> checkRefParamsType funIdStr xs prmMap


    --CheckFDef------------------------------------------------------------------------------------------------------------
    -- controllo delle definizioni di funzioni/procedure
    
    sameParams prmLstStr defPrmMap protPrmMap = case prmLstStr of
       (x:xs) -> if Map.member x defPrmMap
            then if tipo xDefInfo == tipo xProtInfo
                  then if modal xDefInfo == modal xProtInfo
                     then
                        sameParams xs defPrmMap protPrmMap
                     else
                        False
                  else 
                     False
            else
               False
         where
            Just xDefInfo = Map.lookup x defPrmMap 
            Just xProtInfo = Map.lookup x protPrmMap 
       [] -> True
    
    checkFDefList fDefList stack@(local:global) lstxs errs = case fDefList of
       (x:xs) -> case x of
          FunDecl posDef id defPrmList defTipo blocco -> case Map.lookup (idToStr id) (env_fun local) of
             Just (tipoStr1, posProt, isDefined, prmLstStr, prmMap) -> if not isDefined 
                then if tipoStr1 == funTypeToStr defTipo
                   then if length prmLstStr == length defPrmList 
                      then if null newErrs 
                         then if sameParams prmLstStr defPrmMap prmMap
                            then if null compErrs
                               then
                                  checkFDefList 
                                     xs
                                     ((Env {
                                        env_fun = Map.insert idStr (tipoStr1, posProt, True, prmLstStr, prmMap) (env_fun local), 
                                        env_var = env_var local, 
                                        env_const = env_const local, 
                                        block_info = block_info local 
                                     }):global)
                                     ((FunDecl posDef id defPrmList defTipo bloccoNew):lstxs) 
                                     errs
                               else
                                  checkFDefList xs stack lstxs (compErrs ++ errs)
                            else
                               checkFDefList xs stack lstxs (ParamFunDefProtError idStr posDef posProt:errs)
                         else
                            checkFDefList xs stack lstxs (newErrs++errs)
                      else
                         checkFDefList xs stack lstxs (InconsistencyNumParamFunError idStr posDef posProt (length defPrmList) (length prmLstStr):errs)
                   else
                      checkFDefList xs stack lstxs (TypeMismatchFunError idStr posDef posProt (funTypeToStr defTipo) tipoStr1:errs)
                else
                   checkFDefList xs stack lstxs (AlreadyDefinedFunError idStr posDef:errs)
               where
                  idStr = idToStr id
                  (defPrmMap, newErrs) = paramListToMap (idToStr id) defPrmList Map.empty []
                  (bloccoNew, compErrs) = checkCompStmts blocco (Env {
                     env_fun = Map.empty, env_var = insertFormParams prmLstStr prmMap, env_const = Map.empty, 
                     block_info = BlockInfo {name = idToStr id, defPos = posDef, declPos = posProt, tipoStr = tipoStr1, isFunDecl = True, hasReturn = False}
                  }:Env { 
                     env_fun = Map.map setAllFunDefined (env_fun local), env_var = env_var local, env_const = env_const local, block_info = block_info local 
                     } :global)
             Nothing -> checkFDefList xs stack lstxs (UndeclaredFunDefinitionError (idToStr id) posDef :errs)
          ProcDecl posDef id defPrmList blocco -> case Map.lookup (idToStr id) (env_fun local) of
             Just (tipoStr1, posProt, isDefined, prmLstStr, prmMap) -> if not isDefined 
                then if length prmLstStr == length defPrmList
                   then if null newErrs
                      then if sameParams prmLstStr defPrmMap prmMap
                         then if null compErrs
                            then
                               checkFDefList 
                                  xs
                                  ((Env {
                                     env_fun = Map.insert (idToStr id) (tipoStr1, posProt, True, prmLstStr, prmMap) (env_fun local), 
                                     env_var = env_var local, env_const = env_const local, block_info = block_info local 
                                  }):global)
                                  ((ProcDecl posDef id defPrmList bloccoNew):lstxs) 
                                  errs
                            else
                               checkFDefList xs stack lstxs (compErrs ++ errs)
                         else
                            checkFDefList xs stack lstxs (ParamFunDefProtError (idToStr id) posDef posProt:errs)
                      else
                         checkFDefList xs stack lstxs (newErrs++errs)
                   else
                      checkFDefList xs stack lstxs (InconsistencyNumParamFunError (idToStr id) posDef posProt (length defPrmList) (length prmLstStr):errs)
                else
                   checkFDefList xs stack lstxs ((AlreadyDefinedFunError (idToStr id) posDef):errs)
               where
                  (defPrmMap, newErrs) = paramListToMap (idToStr id) defPrmList Map.empty []
                  (bloccoNew, compErrs) = checkCompStmts blocco (Env {
                        env_fun = Map.empty, env_var = insertFormParams prmLstStr prmMap, env_const = Map.empty, 
                        block_info = BlockInfo {name = idToStr id, defPos = posDef, declPos = posProt, tipoStr = tipoStr1, isFunDecl = True, hasReturn = False}
                     }:Env { env_fun = Map.map setAllFunDefined (env_fun local), env_var = env_var local, env_const = env_const local, block_info = block_info local 
                        } :global)
             Nothing -> checkFDefList xs stack lstxs (UndeclaredFunDefinitionError (idToStr id) posDef:errs)
       [] -> (FDefEnv (reverse lstxs) stack, stack, errs) 


    setAllFunDefined (tipoStr, pos, isDef, prmLstStr, prmMap) = (tipoStr, pos, True, prmLstStr, prmMap)


    insertFormParams prmLstStr prmMap = case prmLstStr of
       [] -> Map.empty 
       x:xs -> Map.insert x (VarInfo {varModal = modal prmInfo, varTipo = tipo prmInfo, varPos = pos prmInfo}) (insertFormParams xs prmMap)
         where 
            Just prmInfo = Map.lookup x prmMap


    --CheckDecls-----------------------------------------------------------------------------------------------------------
    --(declsList, declsEnv, declsErr) = checkDecls decls fDefEnv fDefErr
    checkDecls [] stack errs = ([], stack, errs)
    checkDecls (x:xs) stack@(local:global) errs = case x of
       VarDeclAss pos varLst tipo cRExpr -> if null cRExprErrs && null varLstErrs
             then if typeToStr tipo == sup (typeToStr tipo) (getCRexprNewTypeStr cRExprNew)
                then
                   (DeclsEnv (VarDeclAss pos varLst tipo cRExprNew) stack:declsListxs, declsEnvxs, declsErrxs)
                else if head (typeToStr tipo) == '[' && head (typeToStr tipo) == '['
                   then if checkArrAssComp (typeToStr tipo) (getCRexprNewTypeStr cRExprNew)
                      then
                         (DeclsEnv (VarDeclAss pos varLst tipo cRExprNew) stack:declsListxs, declsEnvxs, declsErrxs)
                      else
                         checkDecls xs stackAggiornato (VarDeclTypeError pos (typeToStr tipo) (getCRexprNewTypeStr cRExprNew):errs)
                   else
                     checkDecls xs stackAggiornato (VarDeclTypeError pos (typeToStr tipo) (getCRexprNewTypeStr cRExprNew):errs)
             else
               checkDecls xs stackAggiornato (cRExprErrs ++ varLstErrs ++ errs)
         where
            (cRExprNew, cRExprErrs) = checkCRExpr cRExpr stack
            (stackAggiornato, varLstErrs) = updateLocalVar varLst (typeToStr tipo) stack []
            (declsListxs, declsEnvxs, declsErrxs) = checkDecls xs stackAggiornato errs
       c@(ConstDeclReal pos varLst value) -> if null varLstErrs
          then
             (DeclsEnv c stack:declsListxs, declsEnvxs, declsErrxs)
          else 
             checkDecls xs stackAggiornato (varLstErrs ++ errs)
         where
            (stackAggiornato, varLstErrs) = updateLocalConst varLst "real" (show value) stack []
            (declsListxs, declsEnvxs, declsErrxs) = checkDecls xs stackAggiornato errs
       c@(ConstDeclChar pos varLst value) -> if null varLstErrs
          then
             (DeclsEnv c stack:declsListxs, declsEnvxs, declsErrxs)
          else
             checkDecls xs stackAggiornato (varLstErrs ++ errs)
         where
            (stackAggiornato, varLstErrs) = updateLocalConst varLst "char" (show value) stack []
            (declsListxs, declsEnvxs, declsErrxs) = checkDecls xs stackAggiornato errs
       c@(ConstDeclStr pos varLst value) -> if null varLstErrs
          then
             (DeclsEnv c stack:declsListxs, declsEnvxs, declsErrxs)
          else
             checkDecls xs stackAggiornato (varLstErrs ++ errs)
         where
            (stackAggiornato, varLstErrs) = updateLocalConst varLst "string" (show value) stack []
            (declsListxs, declsEnvxs, declsErrxs) = checkDecls xs stackAggiornato errs
       c@(ConstDeclBool pos varLst value) -> if null varLstErrs
          then
             (DeclsEnv c stack:declsListxs, declsEnvxs, declsErrxs)
          else
             checkDecls xs stackAggiornato (varLstErrs ++ errs)
         where
            (stackAggiornato, varLstErrs) = updateLocalConst varLst "bool" (show value) stack []
            (declsListxs, declsEnvxs, declsErrxs) = checkDecls xs stackAggiornato errs
       c@(ConstDeclInt pos varLst value) -> if null varLstErrs
          then
             (DeclsEnv c stack:declsListxs, declsEnvxs, declsErrxs)
          else
             checkDecls xs stackAggiornato (varLstErrs ++ errs)
         where
            (stackAggiornato, varLstErrs) = updateLocalConst varLst "int" (show value) stack []
            (declsListxs, declsEnvxs, declsErrxs) = checkDecls xs stackAggiornato errs
        
    checkArrAssComp (x:xs) (y:ys) = if x == y 
      then if x /= ']'
         then
            checkArrAssComp xs ys
         else 
            xs == sup xs ys
      else
         False


    --checkStmts-----------------------------------------------------------------------------------------------------------
    checkStmts stmtsList stack@(local:global) stmtsNewLst stmtsErr = case stmtsList of
       x:xs -> case x of
          Comp pos blocco -> if null compStmtErr
                then 
                   checkStmts xs stack ((Comp pos compStmtNew):stmtsNewLst) stmtsErr
                else
                   checkStmts xs stack (x:stmtsNewLst) (compStmtErr ++ stmtsErr)
            where 
               (compStmtNew, compStmtErr) = checkCompStmts blocco ((Env {env_fun = Map.empty, env_var = Map.empty, env_const = Map.empty, block_info = nonFunBlock_info}):stack)
          ProcCall pos (Call posCall id actPrmLst) -> case classe of
               "var" -> checkStmts xs stack (x:stmtsNewLst) (WrongNameFunCallError funIdStr pos posPrec "var":stmtsErr)
               "const" -> checkStmts xs stack (x:stmtsNewLst) (WrongNameFunCallError funIdStr pos posPrec "const":stmtsErr)
               "fun" -> case findFunInStack funIdStr stack of
                  Just (tipoStr, posDef, isDefined, prmLstStr, prmMap) -> if isDefined 
                        then if formLstLen == actLstLen
                           then if null fCallErr
                              then 
                                 checkStmts xs stack ((ProcCall pos (Call pos2 id1 actPrmLst1)):stmtsNewLst) stmtsErr
                              else 
                                 checkStmts xs stack (x:stmtsNewLst) (fCallErr ++ stmtsErr)
                           else 
                              checkStmts xs stack (x:stmtsNewLst) ((FunCallNumArgError funIdStr posCall posDef  formLstLen actLstLen):stmtsErr) 
                        else
                           checkStmts xs stack (x:stmtsNewLst) ((UndefinedFunCallError funIdStr posCall posDef):stmtsErr)
                     where
                        formLstLen = length prmLstStr
                        (FCallNew pos1 (Call pos2 id1 actPrmLst1) tipoStr1, fCallErr) = checkFunCall posCall id stack tipoStr prmLstStr prmMap actPrmLst
                  where
                     actLstLen = length actPrmLst
               "undef" -> checkStmts xs stack (x:stmtsNewLst) ((UndeclaredFunCallError funIdStr posCall):stmtsErr)
            where 
               funIdStr = idToStr id
               (classe, posPrec) = getIdClass funIdStr stack
          Jmp pos jmp -> if (isFunDecl (block_info local))
                then case jmp of
                   RetExpVoid pos -> if tipoStr (block_info local) == "void"
                      then
                         checkStmts xs (Env {env_fun = env_fun local, 
                                             env_var = env_var local,
                                             env_const = env_const local, 
                                             block_info = BlockInfo {
                                                   name = name (block_info local),
                                                   defPos = defPos (block_info local), 
                                                   declPos = declPos (block_info local), 
                                                   tipoStr = tipoStr (block_info local), 
                                                   isFunDecl = isFunDecl (block_info local),
                                                   hasReturn = True
                                                }
                                             }:global) (x:stmtsNewLst) stmtsErr
                      else
                         checkStmts xs stack (x:stmtsNewLst) ((VoidReturnInFunctionError (name (block_info local)) pos (tipoStr (block_info local))):stmtsErr)
                   RetExp pos rExpr -> if null rExprErrs 
                        then if sup rExprTipoStr (tipoStr (block_info local)) == tipoStr (block_info local)
                           then
                              checkStmts xs (Env {env_fun = env_fun local, 
                                             env_var = env_var local,
                                             env_const = env_const local, 
                                             block_info = BlockInfo {
                                                   name = name (block_info local),
                                                   defPos = defPos (block_info local), 
                                                   declPos = declPos (block_info local), 
                                                   tipoStr = tipoStr (block_info local), 
                                                   isFunDecl = isFunDecl (block_info local),
                                                   hasReturn = True
                                                }
                                             }:global) ((Jmp pos (RetExp pos rExprNew)):stmtsNewLst) stmtsErr
                           else
                              checkStmts xs stack (x:stmtsNewLst) ((ReturnMismatchInFunctionError (name (block_info local)) pos (tipoStr (block_info local)) rExprTipoStr):stmtsErr)
                        else
                           checkStmts xs stack (x:stmtsNewLst) (rExprErrs ++ stmtsErr)
                      where
                         (rExprNew, rExprErrs) = checkRexpr rExpr stack
                         rExprTipoStr = getRExprNewTypeStr rExprNew
                else
                   checkStmts xs stack (x:stmtsNewLst) ((ReturnInNonFunBlockError pos):stmtsErr)
          Iter pos iterStmt -> case iterStmt of
             While pos1 rExp stmt1 -> if null rExprErrs && null stmtNewErr
                  then if tipoRExpStr == "bool"
                     then
                        checkStmts xs stack ((Iter pos (While pos1 rExprNew stmt1New)):stmtsNewLst) stmtsErr
                     else 
                        checkStmts xs stack (x:stmtsNewLst) ((NonBoolWardError pos1 tipoRExpStr):stmtsErr)
                  else 
                     checkStmts xs stack (x:stmtsNewLst) (stmtNewErr ++ rExprErrs ++ stmtsErr)
                where
                   (StmtEnv [stmt1New] stackNew, stackNew1, stmtNewErr) = checkStmts [stmt1] stack [] []
                   (rExprNew, rExprErrs) = checkRexpr rExp stack
                   tipoRExpStr = getRExprNewTypeStr rExprNew
             DoWhile pos1 stmt1 rExp -> if null stmtNewErr
                  then if null rExprErrsOk
                     then if tipoRExpStrOk == "bool"
                        then
                           checkStmts xs stackNew ((Iter pos (DoWhile pos1 stmt1New rExprNewOk)):stmtsNewLst) stmtsErr
                        else 
                           checkStmts xs stackNew (x:stmtsNewLst) ((NonBoolWardError pos1 tipoRExpStrOk):stmtsErr)
                     else
                        checkStmts xs stackNew (x:stmtsNewLst) (rExprErrsOk ++ stmtsErr)
                  else if null rExprErrsBad
                     then if tipoRExpStrBad == "bool"
                        then
                           checkStmts xs stack stmtsNewLst (stmtNewErr ++ stmtsErr)
                        else
                           checkStmts xs stack (x:stmtsNewLst) ((NonBoolWardError pos1 tipoRExpStrBad): (stmtNewErr ++ stmtsErr))
                     else
                        checkStmts xs stack (x:stmtsNewLst) (rExprErrsBad ++ stmtNewErr ++ stmtsErr)
                where
                   (StmtEnv [stmt1New] stackNew, stackNew1, stmtNewErr) = checkStmts [stmt1] stack [] []
                   (rExprNewBad, rExprErrsBad) = checkRexpr rExp stack
                   (rExprNewOk, rExprErrsOk) = checkRexpr rExp stackNew
                   tipoRExpStrBad = getRExprNewTypeStr rExprNewBad
                   tipoRExpStrOk = getRExprNewTypeStr rExprNewOk
          Sel pos sel -> case sel of
             IfNoElse pos1 rExp stmtThen -> if null rExprErrs && null stmtNewErr
                  then if tipoRExpStr == "bool"
                     then
                        checkStmts xs stack ((Sel pos (IfNoElse pos1 rExprNew stmt1ThenNew)):stmtsNewLst) stmtsErr
                     else 
                        checkStmts xs stack (x:stmtsNewLst) ((NonBoolWardError pos1 tipoRExpStr):stmtsErr)
                  else 
                     checkStmts xs stack (x:stmtsNewLst) (stmtNewErr ++ rExprErrs ++ stmtsErr)
                where
                   (StmtEnv [stmt1ThenNew] stackNew, stackNew1, stmtNewErr) = checkStmts [stmtThen] stack [] []
                   (rExprNew, rExprErrs) = checkRexpr rExp stack
                   tipoRExpStr = getRExprNewTypeStr rExprNew
             IfElse pos1 rExp stmtThen stmtElse -> if null rExprErrs && null stmtThenErr && null stmtElseErr
                  then if tipoRExpStr == "bool"
                     then
                        checkStmts xs stack ((Sel pos (IfElse pos1 rExprNew stmt1ThenNew stmt1ElseNew)):stmtsNewLst) stmtsErr
                     else 
                        checkStmts xs stack (x:stmtsNewLst) ((NonBoolWardError pos1 tipoRExpStr):stmtsErr)
                  else 
                     checkStmts xs stack (x:stmtsNewLst) (stmtElseErr ++ stmtThenErr ++ rExprErrs ++ stmtsErr)
                where
                   (StmtEnv [stmt1ThenNew] stackThen, stackThenNew1, stmtThenErr) = checkStmts [stmtThen] stack [] []
                   (StmtEnv [stmt1ElseNew] stackElse, stackElseNew1, stmtElseErr) = checkStmts [stmtElse] stack [] []
                   (rExprNew, rExprErrs) = checkRexpr rExp stack
                   tipoRExpStr = getRExprNewTypeStr rExprNew
          Assgn pos l assOp r -> case assOp of
               Assign pos1 -> if null lErrs && null rErrs 
                  then if not (isConst lNew stack)
                     then if supType == tipoLStr
                        then
                           checkStmts xs stack ((Assgn pos lNew (Assign pos1) rNew):stmtsNewLst) stmtsErr
                        else
                           checkStmts xs stack (x:stmtsNewLst) ((TypeAssError pos tipoLStr tipoRStr):stmtsErr)
                     else
                        checkStmts xs stack (x:stmtsNewLst) ((ConstAssError pos lNew):stmtsErr)
                  else
                     checkStmts xs stack (x:stmtsNewLst) (rErrs ++ lErrs ++ stmtsErr)
               AssgnMul pos1 -> if null lErrs && null rErrs 
                  then if not (isConst lNew stack)
                     then if supType == tipoLStr
                        then if supType == "real" || supType == "int" || supType == "bool"
                           then 
                              checkStmts xs stack ((Assgn pos lNew (AssgnMul pos1) rNew):stmtsNewLst) stmtsErr
                           else
                              checkStmts xs stack (x:stmtsNewLst) ((AssgnMatError pos tipoLStr tipoRStr):stmtsErr)
                        else
                           checkStmts xs stack (x:stmtsNewLst) ((TypeAssError pos tipoLStr tipoRStr):stmtsErr)
                     else
                        checkStmts xs stack (x:stmtsNewLst) ((ConstAssError pos lNew):stmtsErr)
                  else
                     checkStmts xs stack (x:stmtsNewLst) (rErrs ++ lErrs ++ stmtsErr)
               AssgnAdd pos1 -> if null lErrs && null rErrs 
                  then if not (isConst lNew stack)
                     then if supType == tipoLStr
                        then if supType == "real" || supType == "int" || supType == "bool"
                           then 
                              checkStmts xs stack ((Assgn pos lNew (AssgnAdd pos1) rNew):stmtsNewLst) stmtsErr
                           else
                              checkStmts xs stack (x:stmtsNewLst) ((AssgnMatError pos tipoLStr tipoRStr):stmtsErr)
                        else
                           checkStmts xs stack (x:stmtsNewLst) ((TypeAssError pos tipoLStr tipoRStr):stmtsErr)
                     else
                        checkStmts xs stack (x:stmtsNewLst) ((ConstAssError pos lNew):stmtsErr)
                  else
                     checkStmts xs stack (x:stmtsNewLst) (rErrs ++ lErrs ++ stmtsErr)
               AssgnDiv pos1 -> if null lErrs && null rErrs 
                  then if not (isConst lNew stack)
                     then if supType == tipoLStr
                        then if supType == "real" || supType == "int" || supType == "bool"
                           then 
                              checkStmts xs stack ((Assgn pos lNew (AssgnDiv pos1) rNew):stmtsNewLst) stmtsErr
                           else
                              checkStmts xs stack (x:stmtsNewLst) ((AssgnMatError pos tipoLStr tipoRStr):stmtsErr)
                        else
                           checkStmts xs stack (x:stmtsNewLst) ((TypeAssError pos tipoLStr tipoRStr):stmtsErr)
                     else
                        checkStmts xs stack (x:stmtsNewLst) ((ConstAssError pos lNew):stmtsErr)
                  else
                     checkStmts xs stack (x:stmtsNewLst) (rErrs ++ lErrs ++ stmtsErr)
               AssgnSub pos1 -> if null lErrs && null rErrs 
                  then if not (isConst lNew stack)
                     then if supType == tipoLStr
                        then if supType == "real" || supType == "int" || supType == "bool"
                           then 
                              checkStmts xs stack ((Assgn pos lNew (AssgnSub pos1) rNew):stmtsNewLst) stmtsErr
                           else
                              checkStmts xs stack (x:stmtsNewLst) ((AssgnMatError pos tipoLStr tipoRStr):stmtsErr)
                        else
                           checkStmts xs stack (x:stmtsNewLst) ((TypeAssError pos tipoLStr tipoRStr):stmtsErr)
                     else
                        checkStmts xs stack (x:stmtsNewLst) ((ConstAssError pos lNew):stmtsErr)
                  else
                     checkStmts xs stack (x:stmtsNewLst) (rErrs ++ lErrs ++ stmtsErr)
               AssgnPow pos1 -> if null lErrs && null rErrs 
                  then if not (isConst lNew stack)
                     then if supType == tipoLStr
                        then if supType == "real" || supType == "int" || supType == "bool"
                           then if tipoRStr == "bool" || tipoRStr == "int"
                              then 
                                 checkStmts xs stack ((Assgn pos lNew (AssgnPow pos1) rNew):stmtsNewLst) stmtsErr
                              else 
                                 checkStmts xs stack (x:stmtsNewLst) ((PowAssgnNonIntExpError pos tipoRStr):stmtsErr)
                           else
                              checkStmts xs stack (x:stmtsNewLst) ((AssgnMatError pos tipoLStr tipoRStr):stmtsErr)
                        else
                           checkStmts xs stack (x:stmtsNewLst) ((TypeAssError pos tipoLStr tipoRStr):stmtsErr)
                     else
                        checkStmts xs stack (x:stmtsNewLst) ((ConstAssError pos lNew):stmtsErr)
                  else
                     checkStmts xs stack (x:stmtsNewLst) (rErrs ++ lErrs ++ stmtsErr)
               AssgnAnd pos1 -> if null lErrs && null rErrs 
                  then if not (isConst lNew stack)
                     then if supType == "bool"
                        then 
                           checkStmts xs stack ((Assgn pos lNew (AssgnAnd pos1) rNew):stmtsNewLst) stmtsErr
                        else 
                           checkStmts xs stack (x:stmtsNewLst) ((AssgnBoolError pos tipoLStr tipoRStr):stmtsErr)
                     else
                        checkStmts xs stack (x:stmtsNewLst) ((ConstAssError pos lNew):stmtsErr)
                  else
                     checkStmts xs stack (x:stmtsNewLst) (rErrs ++ lErrs ++ stmtsErr)
               AssgnOr pos1 -> if null lErrs && null rErrs 
                  then if not (isConst lNew stack)
                     then if supType == "bool"
                        then 
                           checkStmts xs stack ((Assgn pos lNew (AssgnOr pos1) rNew):stmtsNewLst) stmtsErr
                        else 
                           checkStmts xs stack (x:stmtsNewLst) ((AssgnBoolError pos tipoLStr tipoRStr):stmtsErr)
                     else
                        checkStmts xs stack (x:stmtsNewLst) ((ConstAssError pos lNew):stmtsErr)
                  else
                     checkStmts xs stack (x:stmtsNewLst) (rErrs ++ lErrs ++ stmtsErr)
            where
               (lNew, lErrs) = checkBLExpr l stack
               (rNew, rErrs) = checkRexpr r stack
               tipoLStr = getTypeLexpStr lNew
               tipoRStr = getRExprNewTypeStr rNew
               supType = sup (getTypeLexpStr lNew) (getRExprNewTypeStr rNew)
          IncStmt pos l -> if null newErrs
                then if not (isConst lNew stack)
                  then if tipoLNew == "real" || tipoLNew == "int"
                     then
                           checkStmts xs stack (IncStmt pos lNew:stmtsNewLst) stmtsErr
                     else
                        checkStmts xs stack (x:stmtsNewLst) ((NonArithIncDecError pos tipoLNew):stmtsErr)
                  else
                     checkStmts xs stack (x:stmtsNewLst) ((ConstAssError pos lNew):stmtsErr)
                else
                   checkStmts xs stack (x:stmtsNewLst) (newErrs ++ stmtsErr)
            where
               (lNew, newErrs) = checkBLExpr l stack
               tipoLNew = getTypeLexpStr lNew
          DecStmt pos l -> if null newErrs
                then if tipoLNew == "real" || tipoLNew == "int"
                   then
                        checkStmts xs stack (DecStmt pos lNew :stmtsNewLst) stmtsErr
                   else
                      checkStmts xs stack (x:stmtsNewLst) ((NonArithIncDecError pos tipoLNew):stmtsErr)
                else
                   checkStmts xs stack (x:stmtsNewLst) (newErrs ++ stmtsErr)
            where 
               (lNew, newErrs) = checkBLExpr l stack
               tipoLNew = getTypeLexpStr lNew
       [] -> (StmtEnv (reverse stmtsNewLst) stack, stack, stmtsErr)


    --Auxiliary functions--------------------------------------------------------------------------------------------------
    checkCompStmts blocco@(BlockDecl pos protList fDefList declsList stmtsList) stack@(local:global) = (BlockDeclNew pos fDefNewNode declsNewList stmtNewNode, (retErrList ++ stmtErr)) 
      where
         (protEnv, protErr) = checkProt protList stack []
         (fDefNewNode, fDefEnv, fDefErr) = checkFDefList fDefList protEnv [] protErr
         (unDefProtErrs) = verificaProtDefiniz protList fDefEnv
         (declsNewList, declsEnv, declsErr) = checkDecls declsList fDefEnv (unDefProtErrs ++ fDefErr)--ogni elemento della lista di decls ha il suo stack
         (stmtNewNode, stmtEnv, stmtErr) = checkStmts stmtsList declsEnv [] declsErr
         retErrList = checkMissingReturnErr stmtEnv 
    

    checkMissingReturnErr (local:global) = if isFunDecl (block_info local)
         then if hasReturn (block_info local)
            then
               []
            else
               [MissingRetError funName pos tipo] 
         else
            []
      where
         funName = name (block_info local)
         pos = defPos (block_info local)
         tipo = tipoStr (block_info local)
    

    isConst l stack = case l of
      IdNew _ id _ -> fst (getIdClass (idToStr id) stack) == "const"
      _ -> False


    checkCRExpr cRExpr stack = case cRExpr of
       SimpleAss pos rExpr -> (SimpleAssNew pos rExprNew rExprNewTipoStr, rExprErrs)
         where
            (rExprNew, rExprErrs) = checkRexpr rExpr stack
            rExprNewTipoStr = getRExprNewTypeStr rExprNew
       ArrayAss pos cRExprList -> case cRExprList of 
          x:xs -> if null cRExprErrs
                then
                   (ArrayAssNew pos (cRExprNew:xsNew) typeArrayAssNewStr, xsErrs) 
                else
                   (ArrayAssNew pos [] "int", cRExprErrs) --int non ha rilevanza, poichè c'è un errore
            where
               (cRExprNew, cRExprErrs) = checkCRExpr x stack
               cRExprTipoStr = getCRexprNewTypeStr cRExprNew
               (xsNew, tipoArrElem, xsErrs) = checkcRExprList xs stack cRExprTipoStr [] pos 2
               typeArrayAssNewStr = arrayToTypeStr (length cRExprList) tipoArrElem


    checkcRExprList cRExprList stack tipoStr errs pos n = case cRExprList of
       x:xs -> if null cRExprErrs 
             then if head tipoStr == '[' && head cRExprTipoStr == '[' 
                then if dimsTipoStr == getArrTypeDims cRExprTipoStr ""
                   then if supBasType /= "error"
                      then
                         (cRExprNew:crExprListNewArr, supNewArr, newErrsArr)
                      else
                         ([], supErr, newErrsTErr)
                   else
                      ([], supErr, newErrsTErr)
                else if head tipoStr /= '[' && head cRExprTipoStr /= '[' 
                   then if supStr /= "error"
                      then
                         (cRExprNew:crExprListNew, supNew, newErrs)
                      else
                         ([], supErr, newErrsTErr)
                   else
                      ([], supErr, newErrsTErr)
             else
                ([], supErr1, newErrsTErr1)
         where
            dimsTipoStr = getArrTypeDims tipoStr ""
            (crExprListNewArr, supNewArr, newErrsArr) = checkcRExprList xs stack (dimsTipoStr ++ supBasType) (cRExprErrs ++ errs) pos (n+1)
            supBasType = sup (getArrBasType tipoStr) (getArrBasType cRExprTipoStr)
            (cRExprNew, cRExprErrs) = checkCRExpr x stack
            cRExprTipoStr = getCRexprNewTypeStr cRExprNew
            supStr = sup tipoStr cRExprTipoStr
            (crExprListNew, supNew, newErrs) = checkcRExprList xs stack supStr (cRExprErrs ++ errs) pos (n+1)
            (crExprListNewTErr, supErr, newErrsTErr) = 
                     checkcRExprList xs stack tipoStr (ArrayElemTypeInconsistencyError pos n tipoStr cRExprTipoStr:errs) pos (n+1)
            (crExprListNewTErr1, supErr1, newErrsTErr1) = 
                     checkcRExprList xs stack tipoStr (cRExprErrs ++ errs) pos (n+1)
       [] -> ([], tipoStr, errs)


    checkRexpr rExpr stack = case rExpr of
       Or pos l r -> if null lErrs && null rErrs 
             then if supType == "bool"
                then
                   (OrNew pos lNew rNew "bool", [])
                else 
                   (Int Nothing 1, [OrExprError pos lTypeStr rTypeStr supType])
             else 
                (Int Nothing 1, rErrs ++ lErrs)
         where
            (lNew, lErrs) = checkRexpr l stack
            (rNew, rErrs) = checkRexpr r stack
            lTypeStr = getRExprNewTypeStr lNew 
            rTypeStr = getRExprNewTypeStr rNew
            supType = sup lTypeStr rTypeStr
       And pos l r -> if null lErrs && null rErrs 
             then if supType == "bool"
                then
                   (AndNew pos lNew rNew "bool", [])
                else 
                   (Int Nothing 1, [AndExprError pos lTypeStr rTypeStr supType])
             else 
                (Int Nothing 1, rErrs ++ lErrs)
         where
            (lNew, lErrs) = checkRexpr l stack
            (rNew, rErrs) = checkRexpr r stack
            lTypeStr = getRExprNewTypeStr lNew 
            rTypeStr = getRExprNewTypeStr rNew
            supType = sup lTypeStr rTypeStr
       Not pos r -> if null rErrs 
             then if rTypeStr == "bool"
                then
                   (NotNew pos rNew "bool", [])
                else 
                   (Int Nothing 1, [NotExprError pos rTypeStr])
             else 
                (Int Nothing 1, rErrs)
         where
            (rNew, rErrs) = checkRexpr r stack
            rTypeStr = getRExprNewTypeStr rNew
       Eq pos l r -> if null lErrs && null rErrs
               then case supType of
                  "real" -> (EqNew pos lNew rNew "bool", [])
                  "int" -> (EqNew pos lNew rNew "bool", [])
                  "bool" -> (EqNew pos lNew rNew "bool", [])
                  _ -> (Int Nothing 1, [NonNumericComparisonError pos lTypeStr rTypeStr])
             else
                (Int Nothing 1, rErrs ++ lErrs)
         where
            (lNew, lErrs) = checkRexpr l stack
            (rNew, rErrs) = checkRexpr r stack
            lTypeStr = getRExprNewTypeStr lNew
            rTypeStr = getRExprNewTypeStr rNew
            supType = sup lTypeStr rTypeStr
       Neq pos l r -> if null lErrs && null rErrs
               then case supType of
                  "real" -> (NeqNew pos lNew rNew "bool", [])
                  "int" -> (NeqNew pos lNew rNew "bool", [])
                  "bool" -> (NeqNew pos lNew rNew "bool", [])
                  _ -> (Int Nothing 1, [NonNumericComparisonError pos lTypeStr rTypeStr])
             else
                (Int Nothing 1, rErrs ++ lErrs)
         where
            (lNew, lErrs) = checkRexpr l stack
            (rNew, rErrs) = checkRexpr r stack
            lTypeStr = getRExprNewTypeStr lNew
            rTypeStr = getRExprNewTypeStr rNew
            supType = sup lTypeStr rTypeStr
       Lt pos l r -> if null lErrs && null rErrs
               then case supType of
                  "real" -> (LtNew pos lNew rNew "bool", [])
                  "int" -> (LtNew pos lNew rNew "bool", [])
                  "bool" -> (LtNew pos lNew rNew "bool", [])
                  _ -> (Int Nothing 1, [NonNumericComparisonError pos lTypeStr rTypeStr])
             else
                (Int Nothing 1, rErrs ++ lErrs)
         where
            (lNew, lErrs) = checkRexpr l stack
            (rNew, rErrs) = checkRexpr r stack
            lTypeStr = getRExprNewTypeStr lNew
            rTypeStr = getRExprNewTypeStr rNew
            supType = sup lTypeStr rTypeStr
       LtE pos l r -> if null lErrs && null rErrs
               then case supType of
                  "real" -> (LtENew pos lNew rNew "bool", [])
                  "int" -> (LtENew pos lNew rNew "bool", [])
                  "bool" -> (LtENew pos lNew rNew "bool", [])
                  _ -> (Int Nothing 1, [NonNumericComparisonError pos lTypeStr rTypeStr])
             else
                (Int Nothing 1, rErrs ++ lErrs)
         where
            (lNew, lErrs) = checkRexpr l stack
            (rNew, rErrs) = checkRexpr r stack
            lTypeStr = getRExprNewTypeStr lNew
            rTypeStr = getRExprNewTypeStr rNew
            supType = sup lTypeStr rTypeStr
       Gt pos l r -> if null lErrs && null rErrs
               then case supType of
                  "real" -> (GtNew pos lNew rNew "bool", [])
                  "int" -> (GtNew pos lNew rNew "bool", [])
                  "bool" -> (GtNew pos lNew rNew "bool", [])
                  _ -> (Int Nothing 1, [NonNumericComparisonError pos lTypeStr rTypeStr])
             else
                (Int Nothing 1, rErrs ++ lErrs)
         where
            (lNew, lErrs) = checkRexpr l stack
            (rNew, rErrs) = checkRexpr r stack
            lTypeStr = getRExprNewTypeStr lNew
            rTypeStr = getRExprNewTypeStr rNew
            supType = sup lTypeStr rTypeStr
       GtE pos l r -> if null lErrs && null rErrs
               then case supType of
                  "real" -> (GtENew pos lNew rNew "bool", [])
                  "int" -> (GtENew pos lNew rNew "bool", [])
                  "bool" -> (GtENew pos lNew rNew "bool", [])
                  _ -> (Int Nothing 1, [NonNumericComparisonError pos lTypeStr rTypeStr])
             else
                (Int Nothing 1, rErrs ++ lErrs)
         where
            (lNew, lErrs) = checkRexpr l stack
            (rNew, rErrs) = checkRexpr r stack
            lTypeStr = getRExprNewTypeStr lNew
            rTypeStr = getRExprNewTypeStr rNew
            supType = sup lTypeStr rTypeStr
       Add pos l r -> if null lErrs && null rErrs 
             then case supType of 
                "bool" -> (AddNew pos lNew rNew "int", []) -- bool castati a int per l'operazione
                "int" -> (AddNew pos lNew rNew "int", [])
                "real" -> (AddNew pos lNew rNew "real", [])
                _ -> (Int Nothing 1, [SumExprError pos lTypeStr rTypeStr supType])
             else 
                (Int Nothing 1, rErrs ++ lErrs)
         where
            (lNew, lErrs) = checkRexpr l stack
            (rNew, rErrs) = checkRexpr r stack
            lTypeStr = getRExprNewTypeStr lNew
            rTypeStr = getRExprNewTypeStr rNew
            supType = sup lTypeStr rTypeStr
       Sub pos l r -> if null lErrs && null rErrs 
             then case supType of 
                "bool" -> (SubNew pos lNew rNew "int", []) -- bool castati a int per l'operazione
                "int" -> (SubNew pos lNew rNew "int", [])
                "real" -> (SubNew pos lNew rNew "real", [])
                _ -> (Int Nothing 1, [SubExprError pos lTypeStr rTypeStr supType])
             else 
                (Int Nothing 1, rErrs ++ lErrs)
         where
            (lNew, lErrs) = checkRexpr l stack
            (rNew, rErrs) = checkRexpr r stack
            lTypeStr = getRExprNewTypeStr lNew
            rTypeStr = getRExprNewTypeStr rNew
            supType = sup lTypeStr rTypeStr
       Mul pos l r -> if null lErrs && null rErrs 
             then case supType of 
                "bool" -> (MulNew pos lNew rNew "int", []) -- bool castati a int per l'operazione
                "int" -> (MulNew pos lNew rNew "int", [])
                "real" -> (MulNew pos lNew rNew "real", [])
                _ -> (Int Nothing 1, [MulExprError pos lTypeStr rTypeStr supType])
             else 
                (Int Nothing 1, rErrs ++ lErrs)
         where
            (lNew, lErrs) = checkRexpr l stack
            (rNew, rErrs) = checkRexpr r stack
            lTypeStr = getRExprNewTypeStr lNew
            rTypeStr = getRExprNewTypeStr rNew
            supType = sup lTypeStr rTypeStr
       Div pos l r -> if null lErrs && null rErrs 
             then case supType of 
                -- CONTROLLARE SE r E' LA COSTANTE ZERO?
                "bool" -> (DivNew pos lNew rNew "int", []) -- bool castati a int per l'operazione
                "int" -> (DivNew pos lNew rNew "int", [])
                "real" -> (DivNew pos lNew rNew "real", [])
                _ -> (Int Nothing 1, [DivExprError pos lTypeStr rTypeStr supType])
             else 
                (Int Nothing 1, rErrs ++ lErrs)
         where
            (lNew, lErrs) = checkRexpr l stack
            (rNew, rErrs) = checkRexpr r stack
            lTypeStr = getRExprNewTypeStr lNew
            rTypeStr = getRExprNewTypeStr rNew
            supType = sup lTypeStr rTypeStr
       Mod pos l r -> if null lErrs && null rErrs 
             then case supType of 
                -- CONTROLLARE SE r E' LA COSTANTE ZERO?
                "bool" -> (ModNew pos lNew rNew "int", []) -- bool castati a int per l'operazione
                "int" -> (ModNew pos lNew rNew "int", [])
                _ -> (Int Nothing 1, [ModExprError pos lTypeStr rTypeStr supType])
             else 
                (Int Nothing 1, rErrs ++ lErrs)
         where 
            (lNew, lErrs) = checkRexpr l stack
            (rNew, rErrs) = checkRexpr r stack
            lTypeStr = getRExprNewTypeStr lNew
            rTypeStr = getRExprNewTypeStr rNew
            supType = sup lTypeStr rTypeStr
       Pow pos l r -> if null lErrs && null rErrs 
             then case supType of 
                -- SEGNALARE SIA MODEXPR CHE MODNONINTDIV ERROR, SE PRESENTI?
                "bool" -> (PowNew pos lNew rNew "int", []) -- bool castati a int per l'operazione
                "int" -> (PowNew pos lNew rNew "int", [])
                "real" -> if sup rTypeStr "int" == "int"
                   then -- l di tipo float, r di tipo int -> ModNew ha tipo float 
                     (PowNew pos lNew rNew "real", [])
                   else (Int Nothing 1, [PowNonIntExpError pos rTypeStr])
                _ -> (Int Nothing 1, [PowExprError pos lTypeStr rTypeStr supType])
             else 
                (Int Nothing 1, rErrs ++ lErrs)
         where
            (lNew, lErrs) = checkRexpr l stack
            (rNew, rErrs) = checkRexpr r stack
            lTypeStr = getRExprNewTypeStr lNew
            rTypeStr = getRExprNewTypeStr rNew
            supType = sup lTypeStr rTypeStr
       Neg pos r -> if null rErrs 
             then case rTypeStr of 
                "bool" -> (NegNew pos rNew "int", []) -- bool castato a int per l'operazione
                "int" -> (NegNew pos rNew "int", [])
                "real" -> (NegNew pos rNew "real", [])
                _ -> (Int Nothing 1, [NegExprError pos rTypeStr])
             else 
                (Int Nothing 1, rErrs)
         where
            (rNew, rErrs) = checkRexpr r stack
            rTypeStr = getRExprNewTypeStr rNew
       Ref pos r -> if null rErrs 
             then -- r non contiene errori, aggiungo ^ (simbolo di puntatore) al suo tipo
                -- controllare se r è costante 
                (RefNew pos rNew ('^':rTypeStr), [])
             else 
                (Int Nothing 1, rErrs)
         where
            (rNew, rErrs) = checkRexpr r stack
            rTypeStr = getRExprNewTypeStr rNew
       FCall pos (Call posCall id actPrmLst) -> case findFunInStack funIdStr stack of
             Just (tipoStr, posDef, isDefined, prmLstStr, prmMap) -> if isDefined 
                   then if formLstLen == actLstLen
                      then
                         checkFunCall posCall id stack tipoStr prmLstStr prmMap actPrmLst
                      else 
                         (Int Nothing 1, [FunCallNumArgError funIdStr posCall posDef actLstLen formLstLen]) 
                   else
                      (Int Nothing 1, [UndefinedFunCallError funIdStr posCall posDef])
               where
                  formLstLen = length prmLstStr
             Nothing -> (Int Nothing 1, [UndeclaredFunCallError funIdStr posCall])
         where
            funIdStr = idToStr id
            actLstLen = length actPrmLst
       Lexp pos l -> (LexpNew pos lNew lNewTypeStr, newErrs) 
         where 
            (lNew, newErrs) = checkBLExpr l stack
            lNewTypeStr = getTypeLexpStr lNew
       Int pos i -> (Int pos i, [])
       Char pos c -> (Char pos c, [])
       String pos s -> (String pos s, [])
       Float pos d -> (Float pos d, [])
       Bool pos b -> (Bool pos b, [])

   
    getTypeLexpStr lNew = case lNew of
       DerBLExprNew _ _ tipoStr -> tipoStr
       ArrElSqNew _ _ _ tipoStr -> tipoStr
       DerArrPtrNew _ _ _ tipoStr -> tipoStr
       IdNew _ _ tipoStr -> tipoStr


    checkBLExpr bLExpr stack = case bLExpr of
       DerBLExpr pos blNode -> if null newErrs 
             then case bLTypeStr of
                ('^':xs) -> (DerBLExprNew pos bLExprNew xs, [])
                _ -> (Id pos (Ident ""), [DerefError pos bLTypeStr])
             else
                (Id pos (Ident ""), newErrs)
         where
            (bLExprNew, newErrs) = checkBLExpr blNode stack
            bLTypeStr = getTypeLexpStr bLExprNew
       ArrElSq pos id rExprLst -> case classe of
          "var" -> case findVarInStack (idToStr id) stack of
               Just varInfo -> case varTipo varInfo of 
                  ('[':xs) -> if length rExprLst <= getLengthArrTypeStr xs
                        then if null xsErrs
                           then
                              (ArrElSqNew pos id rExprNewLst (getArrAccessTypeStr (varTipo varInfo) (length rExprLst)), [])
                           else
                              (Id pos (Ident ""), xsErrs)
                        else
                           (Id pos (Ident ""), [ArrayAccessDimError idStr pos (getLengthArrTypeStr xs) (length rExprLst)])
                     where
                        (rExprNewLst, xsErrs) = checkArrAccessList rExprLst 1 stack
                  _ -> (Id pos (Ident ""), [ArrayAccessToVarError idStr pos (varTipo varInfo)])
          "const" -> (Id pos (Ident ""), [ArrAccessToConstError idStr pos posPrec])
          "fun" -> (Id pos (Ident ""), [ArrAccessToFunError idStr pos posPrec])
          "undef" -> (Id pos (Ident ""), [UndeclaredVarError pos idStr])
         where 
            idStr = idToStr id
            (classe, posPrec) = getIdClass idStr stack
       DerArrPtr pos bLExpr rExprLst -> if null bLExprErrs
             then case bLExprTipoStr of
                ('^':xs) -> case xs of 
                   ('[':ys) -> if length rExprLst <= getLengthArrTypeStr ys
                         then if null ysErrs
                            then
                               (DerArrPtrNew pos bLExprNew rExprNewLst (getArrAccessTypeStr xs (length rExprLst)), [])
                            else
                               (Id pos (Ident ""), ysErrs)
                         else
                            (Id pos (Ident ""), [DerArrPtrDimError pos (getLengthArrTypeStr xs) (length rExprLst)])
                     where
                        (rExprNewLst, ysErrs) = checkArrAccessList rExprLst 1 stack
                   _ -> (Id pos (Ident ""), [DerArrPtrAccessToVarError pos xs])
                _ -> (Id pos (Ident ""), [DerefError pos bLExprTipoStr])
             else 
                (Id pos (Ident ""), bLExprErrs)
         where
            (bLExprNew, bLExprErrs) = checkBLExpr bLExpr stack
            bLExprTipoStr = getTypeLexpStr bLExprNew
       Id pos id -> case classe of
          "var" -> case findVarInStack (idToStr id) stack of
               Just varInfo -> (IdNew pos id (varTipo varInfo), [])
          "const" -> case findConstInStack (idToStr id) stack of
               Just (tipoStr, _, _) -> (IdNew pos id tipoStr, [])
          "fun" -> (Id pos (Ident ""), [UnexpectedFunIdError idStr pos posPrec])
          "undef" -> (Id pos (Ident ""), [UndeclaredVarError pos idStr])
         where
            idStr = idToStr id
            (classe, posPrec) = getIdClass idStr stack


    -- data lista di rexpr (usate per accesso ad array) e stack, verifica che le rexpr siano prive di errori & abbiano tipo int (o bool) 
    -- n = quale elemento della lista sto esaminando
    -- restituisce: (lista di rexprNew, lista di errori individuati)
    checkArrAccessList rExprLst n stack = case rExprLst of 
       ((RangeArrEl pos rx):rxs) -> if null rxErrs -- rx non contiene errori
             then if "int" == (sup "int" rxNewTypeStr)
                then -- rx ha tipo bool o int
                   ((RangeArrElNew pos rxNew "int"):rxsNew, rxsErrs)
                else -- rx non ha tipo adatto ad accesso a un array
                   ([], (NonIntArrayAccessIndexErr n rxNewTypeStr rxPos :rxsErrs) )
             else -- rx contiene almeno un errore
                ([], (rxErrs ++ rxsErrs))
         where 
            (rxNew, rxErrs) = checkRexpr rx stack
            rxNewTypeStr = getRExprNewTypeStr rxNew
            rxPos = hasPosition rxNew
            (rxsNew, rxsErrs) = checkArrAccessList rxs (n+1) stack
       [] -> ([],[]) -- caso base


    getLengthArrTypeStr xs = case xs of
       (']':_) -> 1 
       (',' : ys) -> 1 + getLengthArrTypeStr ys
       (_:zs) -> getLengthArrTypeStr zs
    

    getArrAccessTypeStr arrTypeStr n = case n of
       0 -> case arrTypeStr of
          ('^':_) -> arrTypeStr --tipo puntatore
          ('[':_) -> arrTypeStr
          ('b':_) -> arrTypeStr --b è bool
          ('c':_) -> arrTypeStr --c è char
          ('i':_) -> arrTypeStr --i è int
          ('r':_) -> arrTypeStr --r è real
          ('s':_) -> arrTypeStr --s è string
          (_:ys) -> '[' : arrTypeStr --in testa c'è un numero
       p -> case arrTypeStr of
          (',':ys) -> getArrAccessTypeStr ys (p-1)
          (']':ys) -> getArrAccessTypeStr ys (p-1)
          (_:ys) ->  getArrAccessTypeStr ys p


   -- cerca nello stack il nome passato e restituisce (classe, posizione)
    getIdClass idStr stack = case stack of
       (x:xs) -> case resVar of
          Just varInfo -> ("var", varPos varInfo)
          Nothing -> case resFun of
             Just (_, pos1, _, _, _) -> ("fun", pos1)
             Nothing -> case resConst of
               Just (_, pos1, _) -> ("const", pos1)
               Nothing -> getIdClass idStr xs    
          where
            resVar = Map.lookup idStr (env_var x)
            resFun = Map.lookup idStr (env_fun x)
            resConst = Map.lookup idStr (env_const x)
       [] -> ("undef", Nothing)

    findVarInStack varIdStr [] = Nothing
    findVarInStack varIdStr (local:global) = case Map.lookup varIdStr (env_var local) of
       Just x -> Just x
       Nothing -> findVarInStack varIdStr global


    findFunInStack funIdStr [] = Nothing
    findFunInStack funIdStr (local:global) = case Map.lookup funIdStr (env_fun local) of
       Just x -> Just x
       Nothing -> findFunInStack funIdStr global


    findConstInStack constIdStr [] = Nothing
    findConstInStack constIdStr (local:global) = case Map.lookup constIdStr (env_const local) of
       Just x -> Just x
       Nothing -> findConstInStack constIdStr global
       

    checkFunCall posCall id stack tipoStr prmLstStr prmMap actPrmLst = case actPrmLst of
       (rx:rxs) -> if null newErrs 
             then case Map.lookup prmIdStr prmMap of
                Just prmInfo -> case modal prmInfo of
                   "in" -> if sup (tipo prmInfo) (getRExprNewTypeStr rxNew) == tipo prmInfo
                      then
                         (FCallNew posCall (Call posCall id (rxNew:rxNewList)) tipoStr, xsErrs)
                      else
                         (FCallNew posCall (Call posCall id []) tipoStr, InModTypeError (idToStr id) (snd (getIdClass (idToStr id) stack)) (hasPosition rxNew) (tipo prmInfo) (getRExprNewTypeStr rxNew):xsErrs)
                   "ref" -> if getRExprNewTypeStr rxNew == tipo prmInfo
                      then case rxNew of
                         (LexpNew posL l tipoStr) -> case l of
                            IdNew _ idL _ -> if not (isConst l stack)
                              then 
                                 (FCallNew posCall (Call posCall id (rxNew:rxNewList)) tipoStr, xsErrs)
                              else
                                 (FCallNew posCall (Call posCall id []) tipoStr, (RefParamConstError (idToStr id) (idToStr idL) (snd (getIdClass (idToStr id) stack)) posL  :xsErrs))
                            _ -> (FCallNew posCall (Call posCall id (rxNew:rxNewList)) tipoStr, xsErrs)
                         _ -> (FCallNew posCall (Call posCall id []) tipoStr, RefParamRExprError (idToStr id) (snd (getIdClass (idToStr id) stack)) (hasPosition rxNew):xsErrs)
                      else
                         (FCallNew posCall (Call posCall id []) tipoStr, RefModTypeError  (idToStr id) (snd (getIdClass (idToStr id) stack)) (hasPosition rxNew) (tipo prmInfo) (getRExprNewTypeStr rxNew):xsErrs)
             else
                (FCallNew posCall (Call posCall id []) tipoStr, newErrs ++ xsErrs)
         where 
            prmIdStr = head prmLstStr
            (rxNew, newErrs) = checkRexpr rx stack
            (FCallNew posCall1 (Call posCall2 id2 rxNewList) tipoStr1, xsErrs) = checkFunCall posCall id stack tipoStr (tail prmLstStr) prmMap rxs
       [] -> (FCallNew posCall (Call posCall id []) tipoStr, [])


    --trasforma lista di parametri nella lista di stringhe dei loro id
    prmListToStrLst prmList = case prmList of
       (Param _ id _ _:xs) -> idToStr id:prmListToStrLst xs
       [] -> []


    arrayToTypeStr dim cRExprTipoStr = case cRExprTipoStr of
       ('[':xs) -> "[" ++ show dim ++ "," ++ xs
       _ -> "[" ++ show dim ++ "]" ++ cRExprTipoStr


    getRExprNewTypeStr rExprNew = case rExprNew of
       OrNew _ _ _ tipoStr -> tipoStr
       AndNew _ _ _ tipoStr -> tipoStr
       NotNew _ _ tipoStr -> tipoStr
       EqNew _ _ _ tipoStr -> tipoStr
       NeqNew _ _ _ tipoStr -> tipoStr
       LtNew _ _ _ tipoStr -> tipoStr
       LtENew _ _ _ tipoStr -> tipoStr
       GtNew _ _ _ tipoStr -> tipoStr
       GtENew _ _ _ tipoStr -> tipoStr
       AddNew _ _ _ tipoStr -> tipoStr
       SubNew _ _ _ tipoStr -> tipoStr
       MulNew _ _ _ tipoStr -> tipoStr
       DivNew _ _ _ tipoStr -> tipoStr
       ModNew _ _ _ tipoStr -> tipoStr
       PowNew _ _ _ tipoStr -> tipoStr
       NegNew _ _ tipoStr -> tipoStr
       RefNew _ _ tipoStr -> tipoStr
       FCallNew _ _ tipoStr -> tipoStr
       LexpNew _ _ tipoStr -> tipoStr
       Int _ _ -> "int"
       Char _ _ -> "char"
       String _ _ -> "string"
       Float _ _ -> "real"
       Bool _ _ -> "bool"


    getCRexprNewTypeStr cRExprNew = case cRExprNew of
       SimpleAssNew _ _ tipoStr -> tipoStr
       ArrayAssNew _ _ tipoStr -> tipoStr


    -- prende un env (local) e una stringa e restituisce True se c'è
    isNameInLoc nameStr env = Map.member nameStr (env_fun env) || 
                              Map.member nameStr (env_var env) || 
                              Map.member nameStr (env_const env)


    idToStr (Ident str) = str


    typeToStr x = case x of
       BasType _ y -> case y of
          BasicType_bool _ -> "bool"
          BasicType_int _ -> "int"
          BasicType_string _ -> "string"
          BasicType_char _ -> "char"
          BasicType_real _ -> "real"
       CompType _ y -> case y of
          ArrDef _ dimList z -> "[" ++ getDimArr dimList ++ "]" ++ typeToStr z
          Pointer _ z -> "^" ++ typeToStr z


    constTypeToStr x = case x of
       BasicType_bool _ -> "bool"
       BasicType_int _ -> "int"
       BasicType_string _ -> "string"
       BasicType_char _ -> "char"
       BasicType_real _ -> "real"


    funTypeToStr x = case x of 
       BasicType_bool _ -> "bool"
       BasicType_int _ -> "int"
       BasicType_string _ -> "string"
       BasicType_char _ -> "char"
       BasicType_real _ -> "real"


    -- data una stringa di un nome già definito nel locale, restituisce la sua posizione nel sorgente
    getPosPrec nameStr local = case Map.lookup nameStr (env_fun local) of
       Just (_, pos, _, _, _) -> pos
       Nothing -> case Map.lookup nameStr (env_var local) of
          Just varInfo -> varPos varInfo
          Nothing -> case Map.lookup nameStr (env_const local) of
             Just (_, pos, _) -> pos
             _ -> Nothing


    getPosPrecInPrmMap nameStr prmMap = case Map.lookup nameStr prmMap of
       Just prmInfo -> pos prmInfo


    -- prende la lista di nomi di var, il locale (fun, var, const) e la lista di errori. Torna (locale aggiornato, nuovi errori)
    updateLocalVar varNameLst tipoStr stack@(local:global) errs = case varNameLst of
       (VarIdent pos name):xs -> if getPosPrec (idToStr name) local == Nothing
          then
             updateLocalVar xs tipoStr (Env {
                env_fun = env_fun local, 
                env_var = Map.insert (idToStr name) (VarInfo {varModal = "pura", varTipo = tipoStr, varPos = pos}) (env_var local),
                env_const = env_const local,
                block_info = block_info local
             }:global) errs
          else
             updateLocalVar xs tipoStr stack (MultipleNameVarError (idToStr name) pos (getPosPrec (idToStr name) local):errs)
       [] -> (stack, errs)


    -- prende la lista di nomi di const, il locale (fun, var, const) e la lista di errori. Torna (locale aggiornato, nuovi errori)
    updateLocalConst varNameLst tipoStr val stack@(local:global) errs = case varNameLst of
       (VarIdent pos name):xs -> if getPosPrec (idToStr name) local == Nothing
          then
             updateLocalConst xs tipoStr val (Env {
                env_fun = env_fun local, 
                env_var = env_var local,
                env_const = Map.insert (idToStr name) (tipoStr, pos, val) (env_const local),
                block_info = block_info local
             }:global) errs
          else
             updateLocalConst xs tipoStr val stack (MultipleNameVarError (idToStr name) pos (getPosPrec (idToStr name) local):errs)
       [] -> (stack, errs)

      
    -- prende lista di parametri, restituisce Map inseribile in un ambiente
    paramListToMap funNameStr prmLst prmMap errs = case prmLst of
       ((Param pos1 name prmMod prmType):xs) -> if Map.member (idToStr name) prmMap
          then
             paramListToMap funNameStr xs prmMap (ParamFunSameNameError funNameStr (idToStr name) pos1 (getPosPrecInPrmMap (idToStr name) prmMap):errs)
          else 
             paramListToMap funNameStr xs (Map.insert (idToStr name) (ParamInfo {modal = modalToStr prmMod, tipo = typeToStr prmType, pos = pos1}) prmMap) errs
       [] -> (prmMap, errs)


    -- prende modalità, restituisce la stringa che la rappresenta 
    modalToStr modal = case modal of
       Modality1 _ -> "in"
       Modality_in _ -> "in"
       Modality_ref _ -> "ref"


    -- inserisce un prototipo nell'env_fun dell'ambiente locale
    insertProtEnv nameStr (tipo, pos, bool, prmLstStr, prmMap) env =
       Env {
          env_fun = Map.insert nameStr (tipo, pos, bool, prmLstStr, prmMap) (env_fun env),
          env_var = env_var env,
          env_const = env_const env,
          block_info = block_info env
       }


    -- funzione ausiliaria a typeToString (caso array/ptr)
    getDimArr [] = ""
    getDimArr (x:xs) = case x of
       ArrDim pos d -> show d ++ (if null xs then "" else ",") ++ getDimArr xs


    -- type-inference
    sup "real" "real" = "real"
    sup "int" "int" = "int"
    sup "bool" "bool" = "bool"
    sup "string" "string" = "string"
    sup "real" "int" = "real"
    sup "int" "real" = "real"
    sup "bool" "int" = "int"
    sup "int" "bool" = "int"
    sup "bool" "real" = "real"
    sup "real" "bool" = "real"
    sup "char" "char" = "char"
    sup "string" "char" = "string"
    sup "char" "string" = "string"
    sup x1@('^':_) x2 = if x1 == x2 
         then
            x1
         else
            "error"
    sup x1@('[':_) x2 = if x1 == x2 
         then
            x1
         else
            "error"
    sup _ _ = "error"


    


    -- data stringa tipo array e stringa vuota, restituisce stringa con le dimensioni dell'array
    -- e.g. dati "[2,3,1]*int" e "", restituisce "[2,3,1]"
    getArrTypeDims arrayTypeStr dimStr = case arrayTypeStr of
        (']':xs) -> dimStr ++ "]"
        (x:xs) -> getArrTypeDims xs (dimStr ++ [x])


    -- dato un tipo array, restituisce il suo tipo "finale" (tipo base o puntatore dopo la chiusura di "[..]")
    -- e.g. dato un tipo [2,5,3]^^[12,6]int, restituisce ^^[12,6]int
    getArrBasType tipoStr = if c == 'b' || c == 'i' || c == 'r' || c == 'c' || c == 's' || c == '^'
        then -- tipoStr è il tipo "finale" dell'array (tipo base o puntatore)
            tipoStr 
        else -- salta al prossimo carattere
            getArrBasType (tail tipoStr)
      where c= head tipoStr