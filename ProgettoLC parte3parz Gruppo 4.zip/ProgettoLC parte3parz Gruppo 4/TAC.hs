{-# OPTIONS_GHC -Wno-incomplete-patterns #-}
module TAC where

    import AbsChapel
    import qualified Data.Map as Map
    import TypeChecker

    -- Partendo dall'albero generato dal type checker, restituisce stringa contenente il relativo tac.
    -- Eventuali corpi di definizioni di funzioni/procedure vengono stampati in coda a
    ---- dichiarazioni di variabili e statements del main, ciascuno preceduto da una label identificativa univoca.
    tacGen (StrtNew _ fDefEnv declsList stmtEnv) = mainLvlLabel ++ tacDecls ++ tacStmt ++ endLvlLabel ++ tacFDefStmt ++ tacFDef ++ 
            "#### static data" ++ tacStrings
        where
            mainLvlLabel = "main@(0,0):\n"
            endLvlLabel = tabs ++ "exit\n"
            tacStrings = tacStringDecls ++ tacStringStmt + tacStringFDef
            (tacDecls, n1, tacStringDecls, k1) = tacDeclsGen declsList 0 "" 0 ""
            (tacStmt, tacFDefStmt, n2, tacStringStmt, k2) = tacStmtGen stmtEnv n1 "" "" k1 "" -- stringa sx: tac stmts; dx: tac fdef interne a compStmts
            (tacFDef, n3, tacStringFDef, k3) = fDefGen fDefEnv n2 "" k2 ""

    -- data stringa temp= *id o id[..], genera nuovo temporaneo in cui memorizza tale valore. 
    -- Restituisce (tac generazione new temp,n+1, new temp)
    -- se temp= id, restituisce ("",n,temp)
    arrDerefTempToNewTemp tipoTemp temp n = if head temp == '*'
        then -- è deref
            (tabs ++ genTemp n ++ " =" ++ (toTacType tipoTemp) ++ " " ++ temp ++"\n"
            , n+1 
            , genTemp n)
        else -- potrebbe essere un array
            if isArrayAccess temp
                then -- accesso array
                    (tabs ++ genTemp n ++ " =" ++ (toTacType tipoTemp) ++ " " ++ temp ++"\n"
                    , n+1 
                    , genTemp n)
                else -- semplice temp
                    ("", n, temp)

    -- dato nome temporaneo, determina se sia accesso ad un array
    isArrayAccess temp= case temp of
        ('[':xs) -> True
        (_:xs) -> isArrayAccess xs 
        [] -> False

    --tacDeclsGen-------------------------------------------------------------------------------------------------------
    tacDeclsGen [] n tacLst k tacString = (tacLst, n, tacString, k)
    tacDeclsGen ((DeclsEnv decl stack):xs) n tacLst k tacString = case decl of
        VarDeclAss pos varLst tipoL cRExprNew -> case cRExprNew of
            SimpleAssNew pos rExpr tipoRStr -> if (head (typeToStr tipoL)) == '[' --cRExpr è una singola rExpr
                then case length varLst of -- la rExpr è di tipo array
                    1 -> -- un solo array da inizializzare a sx (copio valori dalla rExpr)
                            tacDeclsGen xs n3 (tacLst ++ tacRExpr ++ tacNewRTemp ++ tacCopy) k1 (tacString ++ tacStringRExpr)
                        where
                            tipoLStr= typeToStr tipoL
                            (VarIdent posVar1 idVar1) = head varLst
                            tempArrL = idToStr idVar1 ++ getPosStr posVar1
                            arrLBasType= getArrBasType tipoLStr -- e.g. real se tipoL= [..]real
                            arrRBasType= getArrBasType tipoRStr
                            arrRSize= getSizeOf tipoRStr
                            (tacRExpr, n1, tempRExpr, tacStringRExpr, k1) = tacGenRExpr rExpr n stack k-- tac della RExpr
                            (tacNewRTemp, n2, newRTemp)= arrDerefTempToNewTemp tipoLStr tempRExpr n1 -- nuovo temp se necessario
                            (tacCopy,n3,arrLOffset) = genTacArrayCopy tempArrL newRTemp 0 0 -- copia in arrL
                                                      arrLBasType arrRBasType arrRSize n2 ""
                    _ -> -- più array: inizializzo il primo e poi lo copio negli altri
                            tacDeclsGen xs n3 (tacLst ++ tacRExpr ++ tacNewRTemp ++ tacCopy ++ tacCopyRest) k1 (tacString ++ tacStringRExpr)
                        where
                            tipoLStr= typeToStr tipoL
                            (VarIdent posVar1 idVar1) = head varLst
                            arrLTemp = idToStr idVar1 ++ getPosStr posVar1
                            arrLBasType= getArrBasType tipoLStr
                            arrRBasType= getArrBasType tipoRStr
                            arrRSize= getSizeOf tipoRStr
                            (tacRExpr, n1, tempRExpr, tacStringRExpr, k1) = tacGenRExpr rExpr n stack k -- tac della RExpr
                            (tacNewRTemp, n2, newRTemp)= arrDerefTempToNewTemp tipoLStr tempRExpr n1 -- nuovo temp se necessario
                            (tacCopy,n3,arrLOffset) = genTacArrayCopy arrLTemp newRTemp 0 0 -- copia in arrL
                                                      arrLBasType arrRBasType arrRSize n2 ""
                            -- chiama genTacArrayCopy su restanti elementi della lista di id, copiandoci il primo array inizializzato
                            tacCopyRest= genTacArrayCopyRest (tail varLst) arrLTemp  arrLBasType arrRSize ""
                                     
                else -- -- la rExpr è un puntatore o tipo base
                        tacDeclsGen xs n1 (tacLst ++ tacRExpr ++ 
                            (tacVarInitGen varLst (addCastVarInit tipoRStr tipoLStr  tempRExpr)) (typeToStr tipoL)) 
                            k1 
                            (tacString ++ tacStringRExpr) 
                    where 
                    tipoLStr= (typeToStr tipoL)
                    (tacRExpr, n1, tempRExpr, tacStringRExpr, k1) = tacGenRExpr rExpr n stack k

            ArrayAssNew pos cRExprList tipoRStr -> if length varLst == 1 -- cRExpr è un array di altre crExpr
                    then -- un solo array da inizializzare a sx (dalla cRExprList)
                            tacDeclsGen xs n1 (tacLst ++ tacArrInit) k1 (tacString ++ tacStringArr)
                    else -- più array: inizializzo il primo e poi lo copio negli altri
                            tacDeclsGen xs n1 (tacLst ++ tacArrInit ++ tacCopyRest) k1 (tacString ++ tacStringArr)
                where
                    (VarIdent posVar1 idVar1) = head varLst
                    arrLTemp = idToStr idVar1 ++ getPosStr posVar1
                    tipoLStr= typeToStr tipoL
                    arrLBasType= getArrBasType tipoLStr
                    (tacArrInit, n1, tacStringArr, k1) = genTacArrInit stack arrLTemp cRExprList 0 arrLBasType n "" k ""

            --genTacArrInit stack arrLTemp cRExprList arrLOffset arrLBasType n tacArrInit 
                    arrLSize = getSizeOf tipoLStr
                    -- chiama genTacArrayCopy su restanti elementi della lista di id, copiandoci il primo array inizializzato
                    tacCopyRest= genTacArrayCopyRest (tail varLst) arrLTemp arrLBasType arrLSize ""
        ConstDeclStr _ nameLst valStr -> tacDeclsGen xs n tacLst k (tacString ++ tacStringAddr nameLst valStr "")
        _ -> tacDeclsGen xs n tacLst k "" -- dichiarazioni di costanti (ignorate senza aggiungere nulla al tac)


    tacStringAddr nameLst valStr addrStr = case nameLst of
        ((VarIdent pos id):xs) -> tacStringAddr xs valStr 
            (addrStr ++ "ptr$str$" ++ idToStr id ++ getPosStr pos ++ ":     " ++ "\"" ++ valStr ++ "\"" ++ "\n")
        [] -> addrStr


    genTacArrInit stack arrLTemp cRExprList arrLOffset arrLBasType n tacArrInit k tacStringArr = case cRExprList of
        (cr:xs) -> case cr of
            SimpleAssNew pos r tipoRStr -> case tipoRStr of
                ('[':ys) -> --  r è array, copio ogni suo elemento in arrL
                            genTacArrInit stack arrLTemp xs arrLNewOffset arrLBasType n3 
                            (tacArrInit ++ tacRExpr ++ tacNewRTemp ++ tacCopy)
                            k1
                            (tacStringArr ++ tacStringRExpr)
                    where
                        arrRBasType= getArrBasType tipoRStr
                        arrRSize= getSizeOf tipoRStr
                        (tacRExpr, n1, tempRExpr, tacStringRExpr, k1) = tacGenRExpr r n stack k
                        (tacNewRTemp, n2, newRTemp)= arrDerefTempToNewTemp tipoRStr tempRExpr n1 -- nuovo temp se necessario
                        (tacCopy,n3,arrLNewOffset) = genTacArrayCopy arrLTemp newRTemp arrLOffset 0 
                                                      arrLBasType arrRBasType arrRSize n2 ""
                _ -> -- r è singolo puntatore o tipo base
                    genTacArrInit stack arrLTemp xs (arrLOffset+arrLBasSize) arrLBasType n2
                        (tacArrInit ++ tacRExpr ++ tacCastR ++
                        tabs ++ arrLTemp ++ "["++ show arrLOffset ++"] =" ++ (toTacType arrLBasType) ++" "++tempCastR++"\n")
                        k1
                        (tacStringArr ++ tacStringRExpr)
                    where
                        arrLBasSize= getSizeOf arrLBasType
                        (tacRExpr, n1, tempR, tacStringRExpr, k1) = tacGenRExpr r n stack k 
                        (tacCastR, n2, tempCastR) = addCast tempR tipoRStr arrLBasType n1
            ArrayAssNew pos cRExprList1 tipoCRStr -> -- cr è altra list di complex, chiamata ricorsiva aggiuntiva
                genTacArrInit stack arrLTemp xs (arrLOffset+skip) arrLBasType n1
                  (tacArrInit ++ tacArrInit1)
                  k1
                  (tacStringArr ++ tacStringArrInit)
                where
                    crDims= getArrTypeDims tipoCRStr "" -- dimensioni nel tipo dell'array
                    skip= getSizeOf (crDims ++ arrLBasType) -- quanto spazio devo aggiungere all'offset di arrL
                    (tacArrInit1, n1, tacStringArrInit, k1)= genTacArrInit stack arrLTemp cRExprList1 arrLOffset arrLBasType n "" k ""
        _ -> (tacArrInit, n, tacStringArr, k) -- inizializzazione conclusa

        
    -- copia elementi di arr2 in arr1, fermandosi quando l'offset di arr2 raggiunge arr2Size
    -- indirizzi vengono incrementati della dimensione dei loro tipi "finali" (e.g. 4 per array [..]int, 8 per array [..]*..)
    -- tacArrCopy accumula il tac generato, n il minimo indice non utilizzato da temporanei
    genTacArrayCopy arr1Temp arr2Temp arr1Offset arr2Offset arr1BasType arr2BasType arr2Size n tacArrCopy=
        if arr2Offset == arr2Size
            then -- arr2 completamente copiato
                (tacArrCopy, n, arr1Offset) -- arr1Offset = primo indirizzo non modificato
            else -- copia elemento corrente di arr2
                genTacArrayCopy arr1Temp arr2Temp (arr1Offset+(getSizeOf arr1BasType)) (arr2Offset+(getSizeOf arr2BasType))
                    arr1BasType arr2BasType arr2Size n (tacArrCopy ++ tabs ++ lsTac ++ assignTac ++ rsTac)
                where 
                    lsTac= arr1Temp++"["++ show arr1Offset ++"]"
                    assignTac= " =" ++ (toTacType arr1BasType) ++ " "
                    rsTac= (addCastVarInit arr2BasType arr1BasType (arr2Temp++"["++ show arr2Offset ++"]")) ++ "\n"

    -- data lista di id di array e il temporaneo di un array arrR dello stesso tipo, genera il tac della copia di arrR in ogni id
    genTacArrayCopyRest varLst arrRTemp basType size tacArrCopy = case varLst of
        (arrL:xs) -> genTacArrayCopyRest xs arrRTemp basType size (tacArrCopy ++ tacArrCopyNew)
            where 
                (VarIdent posArrL idArrL) = head varLst
                arrLTemp = idToStr idArrL ++ getPosStr posArrL
                (tacArrCopyNew,uselessN,uselessOffset)= 
                    genTacArrayCopy arrLTemp arrRTemp 0 0 basType basType size 0 ""
        _ -> tacArrCopy -- arrR copiato in ogni id



    --------------------------------------- FINE  ARRAY COPY -----------------------------------------------------







    -- data una guardia (rExpr booleana) e due etichette, genera il tac relativo alla valutazione lazy della guardia,
    ---- generando un salto a trueLabel quando la guardia è vera, a falseLabel quando la guardia è false
    tacGuardGen guard stack n trueLabel falseLabel = case guard of
        OrNew pos l r _ -> (tacL ++
                           "L_orLeftFalse" ++ (getPosStr pos)++":\n" ++ tacR -- eseguito se l è falso
                           , n2
                           )
            where
                (tacL,n1)= tacGuardGen l stack n trueLabel ("L_orLeftFalse" ++ (getPosStr pos))
                -- or salta subito a trueLabel se il primo argomento è vero, altrimenti prosegue valutazione
                (tacR,n2)= tacGuardGen r stack n1 trueLabel falseLabel
        AndNew pos l r _ -> (tacL ++
                            "L_andLeftTrue" ++ (getPosStr pos)++":\n" ++ tacR -- eseguito se l è vero 
                            , n2
                            )
            where
                (tacL,n1) = tacGuardGen l stack n ("L_andLeftTrue" ++ (getPosStr pos)) falseLabel
                -- and salta subito a falseLabel se il primo argomento è falso, altrimenti prosegue valutazione
                (tacR,n2) = tacGuardGen r stack n1 trueLabel falseLabel
        NotNew _ r _ -> tacGuardGen r stack n falseLabel trueLabel -- inverto etichette
        _ -> -- in tutti gli altri casi (fcall, confronti...), devo valutare interamente la guardia
             (tacGuard ++ -- genera il temporaneo contenente il valore della guardia
             tabs ++ "if "++tempGuard++ " then goto " ++ trueLabel ++ 
                                " else goto " ++ falseLabel ++ "\n" 
             , n1
             )
            where
                (tacGuard,n1,tempGuard) = tacGenRExpr guard n stack
    

    --tacStmt-----------------------------------------------------------------------------------------------------------
    -- Dato un gruppo di statement e due stringhe accumulatrici di tac, restituisce il tac degli statement
    ---- e il tac di (eventuali) FDef definite all'interno di (eventuali) compStmt
    tacStmtGen (StmtEnv stmtList stack) n tacStmts tacFDefStmt = case stmtList of
         (x:xs) -> case x of
            Comp _ blocco -> tacStmtGen 
                (StmtEnv xs stack)
                n1
                (tacStmts ++ blockStmtsTac) -- aggiungo tac di stmt del blocco
                (tacFDefStmt ++ blockfDefTac) -- aggiungo tac di fDef del blocco 
              where
                (blockStmtsTac, blockfDefTac, n1) = tacCompStmtGen blocco n
            ProcCall _ (Call _ id rExprList) -> tacStmtGen
                (StmtEnv xs stack) n1
                (tacStmts ++ tacParams ++ tabs ++ "proccall " ++ idToStr id ++ getPosStr posProt ++ " / " ++ show numParam ++ "\n")
                tacFDefStmt -- invariato
              where
                (Just (_, posProt, _, prmLstStr, prmMap)) = findFunInStack (idToStr id) stack
                numParam = length prmLstStr
                (tacParams, n1, tacStringParams, k1) = tacGenParam rExprList n stack prmLstStr prmMap "" k ""
            Jmp _ jmp -> case jmp of
                RetExpVoid _ -> tacStmtGen
                    (StmtEnv [] stack) n -- istruzioni successive al return non vengono stampate
                    (tacStmts ++ tabs ++ "return_void \n")
                    tacFDefStmt -- invariato
                RetExp _ r -> tacStmtGen
                        (StmtEnv [] stack) n2 -- istruzioni successive al return non vengono stampate
                        (tacStmts ++ tacR ++ tacCastR ++ tabs ++ "return_" ++ tipoAtteso ++ " " ++ tempCastR ++ "\n")
                        tacFDefStmt -- invariato
                    where 
                        (tacR, n1, tempR) = tacGenRExpr r n stack k
                        tipoR = getRExprNewTypeStr r
                        tipoAtteso = tipoStr (block_info (head stack)) -- tipo di ritorno della funzione
                        (tacCastR, n2, tempCastR) = addCast tempR tipoR tipoAtteso n1
            Iter _ iterStmt -> case iterStmt of
                While pos guard stmt1 -> tacStmtGen
                    (StmtEnv xs stack) n2
                    (tacStmts ++
                    whileGuardLabel ++": \n" ++ tacGuard ++ -- etichetta e tac valutazione guardia
                    whileTrueLabel ++": \n" ++ tacStmts1 ++ -- etichetta e tac guardia vera
                    tabs ++ "goto " ++ whileGuardLabel ++ "\n" ++  -- salta a valutazione guardia
                    whileFalseLabel ++ ": \n" -- etichetta guardia falsa
                    )
                    (tacFDefStmt ++ tacFDefStmt1)
                    where
                        (tacGuard,n1)= tacGuardGen guard stack n whileTrueLabel whileFalseLabel
                        (tacStmts1, tacFDefStmt1, n2) = tacStmtGen (StmtEnv [stmt1] stack) n1 "" ""
                        whileGuardLabel= "while_guard" ++ (getPosStr pos)
                        whileTrueLabel = "while_true" ++ (getPosStr pos)
                        whileFalseLabel = "while_false" ++ (getPosStr pos)
                DoWhile pos stmt1 guard -> tacStmtGen
                    (StmtEnv xs stack) n2
                    (tacStmts ++
                     whileTrueLabel ++": \n" ++ tacStmts1 ++ -- etichetta e tac guardia vera
                     tacGuard ++  -- tac valutazione guardia (salti a etichette sono inclusi)
                     whileFalseLabel ++": \n" -- etichetta guardia falsa
                    )
                    (tacFDefStmt ++ tacFDefStmt1)
                    where
                        (tacStmts1, tacFDefStmt1, n1) = tacStmtGen (StmtEnv [stmt1] stack) n "" ""
                        (tacGuard,n2)= tacGuardGen guard stack n1 whileTrueLabel whileFalseLabel
                        whileTrueLabel = "while_true" ++ (getPosStr pos)
                        whileFalseLabel = "while_false" ++ (getPosStr pos)
            Sel _ sel -> case sel of
                IfNoElse pos guard stmtThen -> tacStmtGen
                    (StmtEnv xs stack) n2
                    (tacStmts ++
                     tacGuard ++ -- tac valutazione guardia
                     ifTrueLabel++ ": \n" ++ tacStmtsThen ++ -- etichetta e tac ramo then
                     ifEndLabel++ ": \n" -- etichetta post-if
                    )
                    (tacFDefStmt ++ tacFDefStmtThen)
                    where
                        (tacGuard,n1)= tacGuardGen guard stack n ifTrueLabel ifEndLabel
                        (tacStmtsThen, tacFDefStmtThen, n2) = tacStmtGen (StmtEnv [stmtThen] stack) n1 "" ""
                        ifTrueLabel = "if_then" ++ (getPosStr pos)
                        ifEndLabel = "if_end" ++ (getPosStr pos)
                IfElse pos guard stmtThen stmtElse ->  tacStmtGen
                    (StmtEnv xs stack) n3
                    (tacStmts ++ 
                     tacGuard ++ -- tac valutazione guardia
                     ifTrueLabel++ ": \n" ++ tacStmtsThen ++ -- etichetta e tac ramo then
                     tabs ++ "goto "++ ifEndLabel ++ "\n" ++ -- salta a post-if
                     ifFalseLabel++ ": \n" ++ tacStmtsElse ++ -- etichetta e tac ramo else
                     ifEndLabel++ ": \n" -- etichetta post-if
                    )
                    (tacFDefStmt ++ tacFDefStmtThen ++ tacFDefStmtElse)
                    where
                        (tacGuard,n1)= tacGuardGen guard stack n ifTrueLabel ifFalseLabel
                        (tacStmtsThen, tacFDefStmtThen, n2) = tacStmtGen (StmtEnv [stmtThen] stack) n1 "" ""
                        (tacStmtsElse, tacFDefStmtElse, n3) = tacStmtGen (StmtEnv [stmtElse] stack) n2 "" ""
                        ifTrueLabel = "if_then" ++ (getPosStr pos)
                        ifFalseLabel = "if_else" ++ (getPosStr pos)
                        ifEndLabel = "if_end" ++ (getPosStr pos)
            Assgn _ l assOp r -> case assOp of 
                    Assign _ -> case tipoL of
                        ('[':ys) -> -- assegnamento array, copio ogni elemento di R in L
                            tacStmtGen
                            (StmtEnv xs stack) n6
                            (tacStmts ++ tacL ++ tacR ++ tacCastR ++ tacNewLTemp ++ tacNewRTemp ++ tacCopy)
                            tacFDefStmt
                        _ -> -- assegnamento puntatore o tipo base
                            tacStmtGen
                            (StmtEnv xs stack) n3
                            (tacStmts ++ tacL ++ tacR ++ tacCastR ++ tabs ++ tempL ++ " =" ++ (toTacType tipoL) ++ 
                                " " ++ tempCastR ++ "\n")
                            tacFDefStmt
                    AssgnMul _ -> tacStmtGen
                        (StmtEnv xs stack) (n3+1)
                        (tacStmts ++ tacL ++ tacR ++ tacCastR ++ 
                            tabs ++ genTemp n3 ++ " =" ++ tipoL ++ " " ++ tempL ++ " mul_" ++ tipoL ++ " " ++ tempCastR ++ "\n" ++
                            tabs ++ tempL ++ " =" ++ tipoL ++ " " ++ genTemp n3 ++ "\n")
                        tacFDefStmt
                    AssgnAdd _ -> tacStmtGen
                        (StmtEnv xs stack) (n3+1)
                        (tacStmts ++ tacL ++ tacR ++ tacCastR ++ 
                            tabs ++ genTemp n3 ++ " =" ++ tipoL ++ " " ++ tempL ++ " add_" ++ tipoL ++ " " ++ tempCastR ++ "\n" ++
                            tabs ++ tempL ++ " =" ++ tipoL ++ " " ++ genTemp n3 ++ "\n")
                        tacFDefStmt
                    AssgnDiv _ -> tacStmtGen
                        (StmtEnv xs stack) (n3+1)
                        (tacStmts ++ tacL ++ tacR ++ tacCastR ++ 
                            tabs ++ genTemp n3 ++ " =" ++ tipoL ++ " " ++ tempL ++ " div_" ++ tipoL ++ " " ++ tempCastR ++ "\n" ++
                            tabs ++ tempL ++ " =" ++ tipoL ++ " " ++ genTemp n3 ++ "\n")
                        tacFDefStmt
                    AssgnSub _ -> tacStmtGen
                        (StmtEnv xs stack) (n3+1)
                        (tacStmts ++ tacL ++ tacR ++ tacCastR ++ 
                            tabs ++ genTemp n3 ++ " =" ++ tipoL ++ " " ++ tempL ++ " sub_" ++ tipoL ++ " " ++ tempCastR ++ "\n" ++
                            tabs ++ tempL ++ " =" ++ tipoL ++ " " ++ genTemp n3 ++ "\n")
                        tacFDefStmt
                    AssgnPow _ -> tacStmtGen
                        (StmtEnv xs stack) (n3+1)
                        (tacStmts ++ tacL ++ tacR ++ tacCastR ++ 
                            tabs ++ genTemp n3 ++ " =" ++ tipoL ++ " " ++ tempL ++ " pow_" ++ tipoL ++ " " ++ tempCastR ++ "\n" ++
                            tabs ++ tempL ++ " =" ++ tipoL ++ " " ++ genTemp n3 ++ "\n")
                        tacFDefStmt
                    AssgnAnd _ -> tacStmtGen
                        (StmtEnv xs stack) (n3+1)
                        (tacStmts ++ tacL ++ tacR ++ tacCastR ++ 
                            tabs ++ genTemp n3 ++ " =" ++ tipoL ++ " " ++ tempL ++ " and_" ++ tipoL ++ " " ++ tempCastR ++ "\n" ++
                            tabs ++ tempL ++ " =" ++ tipoL ++ " " ++ genTemp n3 ++ "\n")
                        tacFDefStmt
                    AssgnOr _ -> tacStmtGen
                        (StmtEnv xs stack) (n3+1)
                        (tacStmts ++ tacL ++ tacR ++ tacCastR ++ 
                            tabs ++ genTemp n3 ++ " =" ++ tipoL ++ " " ++ tempL ++ " or_" ++ tipoL ++ " " ++ tempCastR ++ "\n" ++
                            tabs ++ tempL ++ " =" ++ tipoL ++ " " ++ genTemp n3 ++ "\n")
                        tacFDefStmt
                where 
                    arrLBasType = getArrBasType tipoL
                    arrRBasType = getArrBasType tipoR
                    arrRSize= getSizeOf tipoR -- indirizzi occupati da R
                    (tacL, n1, tempL) = tacGenLexp l stack tipoL n True
                    (tacR, n2, tempR) = tacGenRExpr r n1 stack
                    (tacCastR, n3, tempCastR) = addCast tempR tipoR tipoL n2
                    (tacNewLTemp, n4, newLTemp)= arrDerefTempToNewTemp tipoL tempL n3 -- nuovo temp se necessario (solo per assegnamento array)
                    (tacNewRTemp, n5, newRTemp)= arrDerefTempToNewTemp tipoR tempR n4 -- nuovo temp se necessario (solo per assegnamento array)
                    (tacCopy,n6,arrLNewOffset) = genTacArrayCopy newLTemp newRTemp 0 0 -- copia elementi dell'array
                                                                arrLBasType arrRBasType arrRSize n2 ""
                    tipoL= getTypeLexpStr l
                    tipoR = getRExprNewTypeStr r
            IncStmt _ l -> tacStmtGen
                    (StmtEnv xs stack) (n1+1)
                    (tacStmts ++ tacL ++ tabs ++ genTemp n1 ++ " =" ++ tipoL ++ " " ++ tempL ++ "\n" ++
                      tabs ++ tempL ++ " =" ++ tipoL ++ " " ++ genTemp n1 ++ " add_" ++ tipoL ++ " " ++ (if tipoL == "real" then "1.0" else "1") ++ "\n")
                    tacFDefStmt
                where 
                    tipoL= getTypeLexpStr l
                    (tacL, n1, tempL) = tacGenLexp l stack tipoL n True
            DecStmt _ l -> tacStmtGen
                    (StmtEnv xs stack) (n1+1)
                    (tacStmts ++ tacL ++ tabs ++ genTemp n1 ++ " =" ++ tipoL ++ " " ++ tempL ++ "\n" ++
                      tabs ++ tempL ++ " =" ++ tipoL ++ " " ++ genTemp n1 ++ " sub_" ++ tipoL ++ " " ++ (if tipoL == "real" then "1.0" else "1") ++ "\n")
                    tacFDefStmt
                where 
                    tipoL= getTypeLexpStr l
                    (tacL, n1, tempL) = tacGenLexp l stack tipoL n True
         [] -> (tacStmts, tacFDefStmt, n) -- tac separati: il secondo verrà unito al tac delle FDef dello stesso livello;
                                          --- se mi trovo in blocco di funzione, all'uscita verranno fusi
                                          --- e aggiunti a tacFDefStmt del livello superiore


    --FDefGen---------------------------------------------------------------------------------------------------------------------------------
    -- dato fDefEnv ("lista" di fDef), genera il tac delle fDef nella stringa accumulatrice tacFDef
    fDefGen (FDefEnv fDefList stack) n tacFDef = case fDefList of
        (x:xs) -> case x of
            FunDecl posDecl id _ _ blocco -> fDefGen (FDefEnv xs stack) n1
             (tacFDef ++ -- tac funzioni precedenti
              (idToStr id)++ (getPosStr posDecl)++":\n" -- label del corpo della funzione
              ++ blockStmtsTac -- corpo della funzione
              ++ blockfDefTac -- funzioni definite all'interno della funzione
              )
                where
                    (blockStmtsTac, blockfDefTac, n1) = tacCompStmtGen blocco n
            ProcDecl posDecl id _ blocco -> fDefGen (FDefEnv xs stack) n1
             (tacFDef ++ -- tac funzioni precedenti
              (idToStr id)++ (getPosStr posDecl)++":\n" -- label del corpo della funzione
              ++ blockStmtsTac -- corpo della funzione
              ++ blockfDefTac -- funzioni definite all'interno della funzione 
              )
                where
                    (blockStmtsTac, blockfDefTac, n1) = tacCompStmtGen blocco n
        []-> (tacFDef, n)


    --Auxiliary Functions-----------------------------------------------------------------------------------------------
    -- dato un blocco, genera tac degli statement e delle definizioni di funzioni al suo interno
    tacCompStmtGen (BlockDeclNew _ fDefEnv declsList stmtEnv) n = (blockStmtsTac, blockfDefTac, n3)
        where
            (tacDecls, n1) = tacDeclsGen declsList n ""
            (tacStmt, tacFDefStmt, n2) = tacStmtGen stmtEnv n1 "" "" -- stringa sx: tac stmts, stringa dx: tac fdef interne a compStmts
            (tacFDef, n3) = fDefGen fDefEnv n2 ""
            blockStmtsTac = tacDecls ++ tacStmt
            blockfDefTac = tacFDefStmt ++ tacFDef
    
    -- data una rExpr, genera il tac delle sua valutazione e il nome del temporaneo in cui è memorizzato il suo valore
    tacGenRExpr rExpr n stack k = case rExpr of
        OrNew _ l r tipoAtt -> (tacL ++ tacR ++ tabs ++ genTemp n2 ++ " =bool " ++ tempL ++ " or " ++ tempR ++ "\n"
                                , (n2+1) 
                                , genTemp n2
                                , tacStringL ++ tacStringR
                                , k2)
            where 
                (tacL, n1, tempL, tacStringL, k1) = tacGenRExpr l n stack k
                (tacR, n2, tempR, tacStringR, k2) = tacGenRExpr r n1 stack k1
        AndNew _ l r tipoAtt -> (tacL ++ tacR ++ tabs ++ genTemp n2 ++ " =bool " ++ tempL ++ " and " ++ tempR ++ "\n"
                                , (n2+1) 
                                , genTemp n2
                                , tacStringL ++ tacStringR
                                , k2)
            where 
                (tacL, n1, tempL, tacStringL, k1) = tacGenRExpr l n stack k
                (tacR, n2, tempR, tacStringR, k2) = tacGenRExpr r n1 stack k1
        NotNew _ r tipoAtt -> (tacR ++ tabs ++ genTemp n1 ++ " =bool not " ++ tempR ++ "\n"
                               , (n1+1) 
                               , genTemp n1
                               , tacStringR
                               , k1)
            where
                (tacR, n1, tempR, tacStringR, k1) = tacGenRExpr r n stack k
        EqNew _ l r tipoAtt -> (tacL ++ tacR ++ tacCastL ++ tacCastR ++ 
                            tabs ++ genTemp n4 ++ " =bool " ++ tempCastL ++ " eq_" ++ supType ++ " " ++ tempCastR ++ "\n"
                                , (n4+1) 
                                , genTemp n4
                                , tacStringL ++ tacStringR
                                , k2)
            where
                supType = sup (getRExprNewTypeStr l) (getRExprNewTypeStr r) 
                (tacL, n1, tempL, tacStringL, k1) = tacGenRExpr l n stack k
                (tacR, n2, tempR, tacStringR, k2) = tacGenRExpr r n1 stack k1
                tipoL = getRExprNewTypeStr l
                tipoR = getRExprNewTypeStr r
                (tacCastL, n3, tempCastL) = addCast tempL tipoL supType n2
                (tacCastR, n4, tempCastR) = addCast tempR tipoR supType n3
        NeqNew _ l r tipoAtt -> (tacL ++ tacR ++ tacCastL ++ tacCastR ++ 
                            tabs ++ genTemp n4 ++ " =bool " ++ tempCastL ++ " neq_" ++ supType ++ " " ++ tempCastR ++ "\n"
                                , (n4+1) 
                                , genTemp n4
                                , tacStringL ++ tacStringR
                                , k2)
            where
                supType = sup (getRExprNewTypeStr l) (getRExprNewTypeStr r) 
                (tacL, n1, tempL, tacStringL, k1) = tacGenRExpr l n stack k
                (tacR, n2, tempR, tacStringR, k2) = tacGenRExpr r n1 stack k1
                tipoL = getRExprNewTypeStr l
                tipoR = getRExprNewTypeStr r
                (tacCastL, n3, tempCastL) = addCast tempL tipoL supType n2
                (tacCastR, n4, tempCastR) = addCast tempR tipoR supType n3
        LtNew _ l r tipoAtt -> (tacL ++ tacR ++ tacCastL ++ tacCastR ++ 
                            tabs ++ genTemp n4 ++ " =bool " ++ tempCastL ++ " lt_" ++ supType ++ " " ++ tempCastR ++ "\n"
                                , (n4+1) 
                                , genTemp n4
                                , tacStringL ++ tacStringR
                                , k2)
            where
                supType = sup (getRExprNewTypeStr l) (getRExprNewTypeStr r) 
                (tacL, n1, tempL, tacStringL, k1) = tacGenRExpr l n stack k 
                (tacR, n2, tempR, tacStringR, k2) = tacGenRExpr r n1 stack k1
                tipoL = getRExprNewTypeStr l
                tipoR = getRExprNewTypeStr r
                (tacCastL, n3, tempCastL) = addCast tempL tipoL supType n2
                (tacCastR, n4, tempCastR) = addCast tempR tipoR supType n3
        LtENew _ l r tipoAtt -> (tacL ++ tacR ++ tacCastL ++ tacCastR ++ 
                            tabs ++ genTemp n4 ++ " =bool " ++ tempCastL ++ " lteq_" ++ supType ++ " " ++ tempCastR ++ "\n"
                                , (n4+1) 
                                , genTemp n4
                                , tacStringL ++ tacStringR
                                , k2)
            where
                supType = sup (getRExprNewTypeStr l) (getRExprNewTypeStr r) 
                (tacL, n1, tempL, tacStringL, k1) = tacGenRExpr l n stack k
                (tacR, n2, tempR, tacStringR, k2) = tacGenRExpr r n1 stack k1
                tipoL = getRExprNewTypeStr l
                tipoR = getRExprNewTypeStr r
                (tacCastL, n3, tempCastL) = addCast tempL tipoL supType n2
                (tacCastR, n4, tempCastR) = addCast tempR tipoR supType n3
        GtNew _ l r tipoAtt -> (tacL ++ tacR ++ tacCastL ++ tacCastR ++ 
                            tabs ++ genTemp n4 ++ " =bool " ++ tempCastL ++ " gt_" ++ supType ++ " " ++ tempCastR ++ "\n"
                                , (n4+1) 
                                , genTemp n4
                                , tacStringL ++ tacStringR
                                , k2)
            where
                supType = sup (getRExprNewTypeStr l) (getRExprNewTypeStr r) 
                (tacL, n1, tempL, tacStringL, k1) = tacGenRExpr l n stack k
                (tacR, n2, tempR, tacStringR, k2) = tacGenRExpr r n1 stack k1
                tipoL = getRExprNewTypeStr l
                tipoR = getRExprNewTypeStr r
                (tacCastL, n3, tempCastL) = addCast tempL tipoL supType n2
                (tacCastR, n4, tempCastR) = addCast tempR tipoR supType n3
        GtENew _ l r tipoAtt -> (tacL ++ tacR ++ tacCastL ++ tacCastR ++ 
                            tabs ++ genTemp n4 ++ " =bool " ++ tempCastL ++ " gteq_" ++ supType ++ " " ++ tempCastR ++ "\n"
                                , (n4+1) 
                                , genTemp n4
                                , tacStringL ++ tacStringR
                                , k2)
            where
                supType = sup (getRExprNewTypeStr l) (getRExprNewTypeStr r) 
                (tacL, n1, tempL, tacStringL, k1) = tacGenRExpr l n stack k 
                (tacR, n2, tempR, tacStringR, k2) = tacGenRExpr r n1 stack k1
                tipoL = getRExprNewTypeStr l
                tipoR = getRExprNewTypeStr r
                (tacCastL, n3, tempCastL) = addCast tempL tipoL supType n2
                (tacCastR, n4, tempCastR) = addCast tempR tipoR supType n3
        AddNew _ l r tipoAtt -> (tacL ++ tacR ++ tacCastL ++ tacCastR ++ 
                            tabs ++ genTemp n4 ++ " =" ++ supType ++ " " ++ tempCastL ++ " add_" ++ supType ++ " " ++ tempCastR ++ "\n"
                                , (n4+1) 
                                , genTemp n4
                                , tacStringL ++ tacStringR
                                , k2)
            where
                supType = sup (getRExprNewTypeStr l) (getRExprNewTypeStr r) 
                (tacL, n1, tempL, tacStringL, k1) = tacGenRExpr l n stack k 
                (tacR, n2, tempR, tacStringR, k2) = tacGenRExpr r n1 stack k1
                tipoL = getRExprNewTypeStr l
                tipoR = getRExprNewTypeStr r
                (tacCastL, n3, tempCastL) = addCast tempL tipoL supType n2
                (tacCastR, n4, tempCastR) = addCast tempR tipoR supType n3 
        SubNew _ l r tipoAtt -> (tacL ++ tacR ++ tacCastL ++ tacCastR ++ 
                            tabs ++ genTemp n4 ++ " =" ++ supType ++ " " ++ tempCastL ++ " sub_" ++ supType ++ " " ++ tempCastR ++ "\n"
                                , (n4+1) 
                                , genTemp n4
                                , tacStringL ++ tacStringR
                                , k2)
            where
                supType = sup (getRExprNewTypeStr l) (getRExprNewTypeStr r) 
                (tacL, n1, tempL, tacStringL, k1) = tacGenRExpr l n stack k 
                (tacR, n2, tempR, tacStringR, k2) = tacGenRExpr r n1 stack k1
                tipoL = getRExprNewTypeStr l
                tipoR = getRExprNewTypeStr r
                (tacCastL, n3, tempCastL) = addCast tempL tipoL supType n2
                (tacCastR, n4, tempCastR) = addCast tempR tipoR supType n3 
        MulNew _ l r tipoAtt -> (tacL ++ tacR ++ tacCastL ++ tacCastR ++ 
                            tabs ++ genTemp n4 ++ " =" ++ supType ++ " " ++ tempCastL ++ " mul_" ++ supType ++ " " ++ tempCastR ++ "\n"
                                , (n4+1) 
                                , genTemp n4
                                , tacStringL ++ tacStringR
                                , k2)
            where
                supType = sup (getRExprNewTypeStr l) (getRExprNewTypeStr r) 
                (tacL, n1, tempL, tacStringL, k1) = tacGenRExpr l n stack k
                (tacR, n2, tempR,tacStringR, k2) = tacGenRExpr r n1 stack k1
                tipoL = getRExprNewTypeStr l
                tipoR = getRExprNewTypeStr r
                (tacCastL, n3, tempCastL) = addCast tempL tipoL supType n2
                (tacCastR, n4, tempCastR) = addCast tempR tipoR supType n3 
        DivNew _ l r tipoAtt -> (tacL ++ tacR ++ tacCastL ++ tacCastR ++ 
                            tabs ++ genTemp n4 ++ " =" ++ supType ++ " " ++ tempCastL ++ " div_" ++ supType ++ " " ++ tempCastR ++ "\n"
                                , (n4+1) 
                                , genTemp n4
                                , tacStringL ++ tacStringR
                                , k2)
            where
                supType = sup (getRExprNewTypeStr l) (getRExprNewTypeStr r) 
                (tacL, n1, tempL, tacStringL, k1) = tacGenRExpr l n stack k
                (tacR, n2, tempR, tacStringR, k2) = tacGenRExpr r n1 stack k1
                tipoL = getRExprNewTypeStr l
                tipoR = getRExprNewTypeStr r
                (tacCastL, n3, tempCastL) = addCast tempL tipoL supType n2
                (tacCastR, n4, tempCastR) = addCast tempR tipoR supType n3 
        ModNew _ l r tipoAtt -> (tacL ++ tacR ++ tacCastL ++ tacCastR ++ 
                            tabs ++ genTemp n4 ++ " =" ++ supType ++ " " ++ tempCastL ++ " mod_" ++ supType ++ " " ++ tempCastR ++ "\n"
                                , (n4+1) 
                                , genTemp n4
                                , tacStringL ++ tacStringR
                                , k2)
            where
                supType = sup (getRExprNewTypeStr l) (getRExprNewTypeStr r) 
                (tacL, n1, tempL, tacStringL, k1) = tacGenRExpr l n stack k 
                (tacR, n2, tempR, tacStringR, k2) = tacGenRExpr r n1 stack k1
                tipoL = getRExprNewTypeStr l
                tipoR = getRExprNewTypeStr r
                (tacCastL, n3, tempCastL) = addCast tempL tipoL supType n2
                (tacCastR, n4, tempCastR) = addCast tempR tipoR supType n3 
        PowNew _ l r tipoAtt -> (tacL ++ tacR ++ tacCastL ++ tacCastR ++ 
                            tabs ++ genTemp n4 ++ " =" ++ supType ++ " " ++ tempCastL ++ " pow_" ++ supType ++ " " ++ tempCastR ++ "\n"
                                , (n4+1) 
                                , genTemp n4
                                , tacStringL ++ tacStringR
                                , k2)
            where
                supType = sup (getRExprNewTypeStr l) (getRExprNewTypeStr r) 
                (tacL, n1, tempL, tacStringL, k1) = tacGenRExpr l n stack k
                (tacR, n2, tempR, tacStringR, k2) = tacGenRExpr r n1 stack k1
                tipoL = getRExprNewTypeStr l
                tipoR = getRExprNewTypeStr r
                (tacCastL, n3, tempCastL) = addCast tempL tipoL supType n2
                (tacCastR, n4, tempCastR) = addCast tempR tipoR supType n3 
        NegNew _ r tipoAtt -> (tacR ++ tabs ++ genTemp n1 ++ " =" ++ tipoAtt ++ " neg_" ++ tipoAtt ++ " " ++ tempR ++ "\n"
                               , (n1+1) 
                               , genTemp n1
                               , tacStringR
                               , k1)
            where
                (tacR, n1, tempR, tacStringR, k1) = tacGenRExpr r n stack k
        RefNew _ r tipoAtt -> (tacR ++ tabs ++ genTemp n1 ++ " =addr &" ++ tempR ++ "\n"
                               , (n1+1) 
                               , genTemp n1
                               , tacStringR
                               , k1)
            where
                tipoR = getRExprNewTypeStr r 
                (tacR, n1, tempR, tacStringR, k1) = tacGenRExpr r n stack k
        FCallNew posFCall (Call posCall id rxNewList) tipoAtt -> 
            (tacParams ++ 
             tabs ++ genTemp n1 ++ " =" ++ (toTacType tipoAtt) ++ " fcall " ++ idToStr id ++ getPosStr posProt ++ " / " ++ show numParam ++ "\n"
            , (n1+1) 
            , genTemp n1
            , tacStringParams
            , k1)
            where
                (Just (_, posProt, _, prmLstStr, prmMap)) = findFunInStack (idToStr id) stack
                numParam = length prmLstStr
                -- genero tac di preparazione dei parametri da passare alla chiamata
                (tacParams, n1, tacStringParams, k1) = tacGenParam rxNewList n stack prmLstStr prmMap "" k ""
        LexpNew _ l tipoAtt -> tacGenLexp l stack tipoAtt n True k
        -- per tipi base, restituisco direttamente il loro valore
        Int _ val -> ("", n, show val, "", k)
        Char _ val -> ("", n, val:[], "", k) 
        String _ val -> ("", n, genStrLabel k, ((genStrLabel k) ++ ":     " ++ "\"" ++ val ++ "\""), k+1)
        Float _ val -> ("", n, show val, "", k)
        Bool _ bool -> case bool of
            Boolean_true _ -> ("", n, "true", "", k)
            Boolean_false _ -> ("", n, "false", "", k)

    -- Data una lExpr l, genero il tac della sua valutazione e il temporaneo in cui è salvato il suo valore
    -- isTopLevel è un booleano che indica se sto valutando l al top-level:
    ---- se è vero, restituisco direttamente il temporaneo associato a l (e.g. a_15_2[t_13], *b_7_6)
    ---- altrimenti, genero un temp aggiuntivo (e.g. t_14= a_15_2[t_13], t_42= *b_7_6) 
    tacGenLexp l stack tipoAtt n isTopLevel k = if isTopLevel 
        then case l of
                -- deref di blNode
                DerBLExprNew pos blNode tipoAtt1 -> 
                    (tacBLNode -- tac valutazione blNode
                    , n1
                    , ("*" ++ tempBLNode) -- temp restituito
                    , tacStringBLNode
                    , k1)
                    where
                        (tacBLNode, n1, tempBLNode, tacStringBLNode, k1) = tacGenLexp blNode stack tipoAtt n False k
                -- accesso ad array id
                ArrElSqNew pos id rExprLst tipoAtt1 -> 
                        (tacRList -- tac valutazione della rExprList e calcolo dell'indice d'accesso
                        , n1
                        , nomeArray ++ "[" ++ tempOffSet ++ "]" -- temp restituito
                        , tacStringRList
                        , k1) 
                    where
                        nomeArray = idToStr id ++ getPosStr (snd (getIdClass (idToStr id) stack))
                        Just varInfo = findVarInStack (idToStr id) stack
                        tipoArray = varTipo varInfo
                        (tacRList, n1, tempOffSet, tacStringRList, k1) = tacGenRList (getSizeOf tipoArray) tipoArray rExprLst stack n "0" "" k ""

                -- accesso di tipo array su valore ottenuto da deref di blNode 
                DerArrPtrNew pos blNode rExprLst tipoAtt1 -> 
                        (tacBLNode ++ -- tac valutazione blNode
                        tabs ++ genTemp n1 ++ " =addr *" ++ tempBLNode ++ "\n" ++ -- assegno valore blNode a nuovo temp
                        tacRList -- tac valutazione della rExprList e calcolo dell'indice d'accesso
                        , (n2+1)
                        , (genTemp n2) ++ "[" ++ tempOffSet ++ "]" -- temp restituito
                        , tacStringBLNode ++ tacStringRList
                        , k2) 
                    where
                        (tacBLNode, n1, tempBLNode, tacStringBLNode, k1) = tacGenLexp blNode stack tipoAtt n False k
                        tipoArray = tail (getTypeLexpStr blNode)
                        (tacRList, n2, tempOffSet, tacStringRList, k2) = tacGenRList (getSizeOf tipoArray) tipoArray rExprLst stack n "0" "" k1 ""
                -- accesso a variabile
                IdNew pos id tipoAtt1 -> case fst classPos of
                    "var" -> if varModal varInfo == "ref"
                        then -- id è un parametro formale passato per riferimento, faccio un deref su id
                            ("", n, "*" ++ (idToStr id) ++ getPosStr (snd classPos), "", k)
                        else -- id è una normale variabile
                            ("", n, (idToStr id) ++ getPosStr (snd classPos), "", k)
                    "const" -> case tipoAtt1 of
                        "string" -> ("", n, genStrLabel k ++ getPosStr (snd classPos), "", k)
                        _ -> ("", n, val, "", k) -- id è una costante, ne restituisco direttamente il valore
                    where
                        Just varInfo = findVarInStack (idToStr id) stack
                        classPos = getIdClass (idToStr id) stack
                        Just (_, _, val) = findConstInStack (idToStr id) stack
        else case l of
                -- deref di blNode
                DerBLExprNew pos blNode tipoAtt1 -> 
                    (tacBLNode ++ -- valutazione blNode
                     tabs ++ genTemp n1 ++ " =" ++ (toTacType tipoAtt1) ++ " *" ++ tempBLNode ++ "\n" -- salvo blNode in nuovo temp
                    , n1+1
                    , genTemp n1
                    , tacStringBLNode
                    , k1)
                    where
                        (tacBLNode, n1, tempBLNode, tacStringBLNode, k1) = tacGenLexp blNode stack tipoAtt n False k
                -- accesso ad array
                ArrElSqNew pos id rExprLst tipoAtt1 -> 
                    (tacRList ++ 
                     tabs ++ genTemp n1 ++ " =" ++ (toTacType tipoAtt1) ++ " " ++ nomeArray ++ "[" ++ tempOffSet ++ "]" ++ "\n"
                        -- salvo valore acceduto in nuovo temp
                    , n1+1
                    , genTemp n1
                    , tacStringRList
                    , k1)
                    where
                        nomeArray = idToStr id ++ getPosStr (snd (getIdClass (idToStr id) stack))
                        Just varInfo = findVarInStack (idToStr id) stack
                        tipoArray = varTipo varInfo
                        (tacRList, n1, tempOffSet, tacStringRList, k1) = tacGenRList (getSizeOf tipoArray) tipoArray rExprLst stack n "0" "" k ""
                -- accesso di tipo array su valore ottenuto da deref di blNode
                DerArrPtrNew pos blNode rExprLst tipoAtt1 -> 
                    (tacBLNode ++ 
                     tabs ++ genTemp n1 ++ " =addr *" ++ tempBLNode ++ "\n" ++ -- assegno valore blNode a nuovo temp
                     tacRList ++ -- tac valutazione della rExprList e calcolo dell'indice d'accesso
                     -- salvo valore acceduto in nuovo temp
                     tabs ++ genTemp n2 ++ " =" ++ tipoAtt1 ++ " " ++ (genTemp n1) ++ "[" ++ tempOffSet ++ "]" ++ "\n"
                    , n2+1
                    , genTemp n2
                    , tacStringBLNode ++ tacStringRList
                    , k2)
                    where
                        (tacBLNode, n1, tempBLNode, tacStringBLNode, k1) = tacGenLexp blNode stack tipoAtt n False k
                        tipoArray = tail (getTypeLexpStr blNode) 
                        (tacRList, n2, tempOffSet, tacStringRList, k2) = tacGenRList (getSizeOf tipoArray) tipoArray rExprLst stack n1 "0" "" k1 ""
                -- accesso a variabile
                IdNew pos id tipoAtt1 -> case fst classPos of
                        "var" -> ("", n, (idToStr id) ++ getPosStr (snd classPos), "", k) -- normale variabile
                        "const" -> ("", n, val, "", k) -- costante
                        -- nota: questo caso non dovrebbe mai verificarsi (const possono trovarsi solo al top-level di una LExpr)
                    where
                    classPos = getIdClass (idToStr id) stack
                    Just (_, _, val) = findConstInStack (idToStr id) stack


    -- Data una lista di RExpr che fungono da indici d'accesso ad un array, 
    ---- restituisce il tac della loro valutazione e l'offset per accedere all'array
    -- sizeTipoArr= dimensione (indirizzi occupati) dall'array
    -- tempVal= valore dell'offset accumulato finora, tacRList= tac generato finora nella valutazione della rExprList
    tacGenRList sizeTipoArr tipoArray rExprLst stack n tempVal tacRList k tacStringRList = case rExprLst of
        ((RangeArrElNew _ r _):xs) -> if tempVal == "0"
            then -- offset accumulato = 0, non serve sommarlo a quello calcolato 
                tacGenRList pesoAttuale tipoXS xs stack (n2+1) (genTemp (n2))
                    (tacRList ++ tacR ++ tacCastR ++ -- tac precedente + tac valutazione di r (e cast, se r è bool)
                     -- salva offset dato da r (valore r * pesoAttuale) in nuovo temp
                     tabs ++ genTemp n2 ++ " =int " ++ tempCastR ++ " mul_int " ++ show pesoAttuale ++ " # indice * peso \n")
                     k1
                     (tacStringRList ++ tacStringR) 
            else -- 
                 tacGenRList pesoAttuale tipoXS xs stack (n2+2) (genTemp (n2+1))
                    (tacRList ++ tacR ++ tacCastR ++ -- tac precedente + tac valutazione di r (e cast, se r è bool)
                     -- salva offset dato da r (valore r * pesoAttuale) in nuovo temp
                     tabs ++ genTemp n2 ++ " =int " ++ tempCastR ++ " mul_int " ++ show pesoAttuale ++ " # indice * peso \n" ++
                     -- salva offset complessivo (tempVal + offset di r) in nuovo temp
                     tabs ++ genTemp (n2+1) ++ " =int " ++ genTemp n2 ++ " sum_int " ++ tempVal ++ " # offset attuale \n")
                     k1
                     (tacStringRList ++ tacStringR)
            where
                (tacR, n1, tempR, tacStringR, k1) = tacGenRExpr r n stack k
                tipoR= getRExprNewTypeStr r
                (tacCastR, n2, tempCastR) = addCast tempR tipoR "int" n1
                (val, tipoXS) = getValInArr (tail tipoArray) ""
                pesoAttuale = div sizeTipoArr val -- peso da moltiplicare per il valore dell'elemento corrente della rExprLst 
        [] -> (tacRList, n, tempVal, tacStringRList, k) -- restituisce tac e offset finale

    -- data lista di rExpr (parametri attuali di chiamata a funzione),
    -- restituisce tac che prepara parametri prima della chiamata 
    tacGenParam rxNewList n stack prmLstStr prmMap tacPrmStr k tacStringParams = case rxNewList of
        (r:rs) -> case modal prmInfo of
                "in" -> tacGenParam 
                            rs 
                            n2
                            stack
                            (tail prmLstStr)
                            prmMap
                            (tacPrmStr ++ tacR ++ tacCastR ++ -- tac precedente + valutazione (e cast) di r
                             "param_" ++ (toTacType (tipo prmInfo)) ++ " " ++ tempCastR ++ "\n") -- prepara parametro
                            k1
                            (tacStringParams ++ tacStringR)
                "ref" -> tacGenParam 
                            rs 
                            n1
                            stack
                            (tail prmLstStr)
                            prmMap
                            (tacPrmStr ++ tacR ++ tacCastR ++ -- tac precedente + valutazione (e cast) di r
                            -- NB: cast inutile, dato che per rif. tipi attuali e formali devono essere identici?
                             "param_addr &" ++ tempCastR ++ "\n") -- prepara parametro
                            k1
                            (tacStringParams ++ tacStringR)
            where 
                prmName = head prmLstStr
                Just prmInfo = Map.lookup prmName prmMap
                (tacR, n1, tempR, tacStringR, k1) = tacGenRExpr r n stack k
                (tacCastR, n2, tempCastR) = addCast tempR (getRExprNewTypeStr r) (tipo prmInfo) n1 
        [] -> (tacPrmStr, n, tacStringParams, k)

    -- dato temporaneo tempExp, tipo del temporaneo tipoExp e tipo atteso tipoAtt,
    ---- restituisce tac dell'operazione di cast da tipoExp a tipoAtt, se necessario (salvando risultato del cast in un nuovo temp) 
    addCast tempExp tipoExp tipoAtt n = if tipoExp == tipoAtt 
        then -- nessun cast necessario
            ("", n, tempExp)
        else -- cast necessario
            (tabs ++ genTemp n ++ " =" ++ (toTacType tipoAtt) ++ convertTypeStr tipoExp tipoAtt ++ " " ++ tempExp ++ "\n" -- tac del cast
            , n+1, genTemp n)

    -- data lista di id e un temporaneo tempRExpr, genera tac di assegnamento di tempRExpr ad ogni id della lista
    tacVarInitGen [] _ tipoLStr = "" 
    tacVarInitGen ((VarIdent pos id):xs) tempRExpr tipoLStr =
        tabs ++ idToStr id ++ getPosStr pos ++ " =" ++ (toTacType tipoLStr) ++ " " ++ tempRExpr ++ "\n" ++ -- assegnamento di tempRExpr
        (tacVarInitGen xs tempRExpr tipoLStr) -- chiamata ricorsiva sul resto della lista

    -- dato temporaneo, il suo tipo e il tipo atteso, restituisce il temporaneo se i due tipi coincidono, tac del cast altrimenti
    addCastVarInit tipoR tipoAtteso tempR = if tipoAtteso == tipoR
        then -- nessun cast necessario, restituisce il temp originale
            tempR
        else -- cast necessario, restituisce " convert-TipoR-to-TipoAtteso tempR"
            convertTypeStr tipoR tipoAtteso ++ " " ++ tempR

    -- dato un tipo, restituisce il numero di indirizzi occupati
    getSizeOf str1 = case str1 of
            "int" -> 4
            "real" -> 8
            "bool" -> 1
            "char" -> 1
            "string" -> 8
            ('^':xs) -> 8
            ('[':xs) -> valHead * getSizeOf xsStr
                where
                    (valHead, xsStr) = getValInArr xs ""

    -- data una stringa "n1,..]abc", con n1 intero, restituisce la coppia (n1,"[..]abc")
    getValInArr str1 numStr = case str1 of
        (',':xs) -> (read numStr :: Integer, '[':xs)
        (']':xs) -> (read numStr :: Integer, xs)
        (c:xs) -> getValInArr xs (numStr ++ [c])

    tabs = "     " -- per indentazione

    -- data posizione riga-colonna, restituisce stringa "@r,c"
    getPosStr (Just (r, c)) = "@" ++ show r ++ "," ++ show c

    -- dato intero n, genera temporaneo "t_n"
    genTemp n = "t_" ++ show n


    -- generazione etichette per le stringhe
    genStrLabel k = "ptr$str$" ++ show k


    -- dati due tipi, genera stringa di cast
    -- e.g. tipo1= int, tipo 2= real -> "real convert-int-to-real"
    convertTypeStr tipoStr1 tipoStr2 =              " convert-" ++ tipoStr1 ++ "-to-" ++ tipoStr2
                                      --tipoStr2 ++ (non necessario, in quanto già stampato dall'assegnamento)

    -- dato un tipo, restituisce "addr"  se il tipo è un array o puntatore (o una stringa)
    -- altrimenti, restituisce il tipo immutato
    toTacType tipoStr = case tipoStr of 
        ('[':xs) -> "addr" -- tipo array
        ('^':xs) -> "addr" -- tipo puntatore
        ('s':xs) -> "addr" -- tipo stringa
        _ -> tipoStr -- qualunque altro tipo